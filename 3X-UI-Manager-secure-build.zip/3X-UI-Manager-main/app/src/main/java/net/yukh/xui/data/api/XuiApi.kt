package net.yukh.xui.data.api

import net.yukh.xui.data.api.dto.ApiAck
import net.yukh.xui.data.api.dto.BulkAdjustRequest
import net.yukh.xui.data.api.dto.BulkAdjustResult
import net.yukh.xui.data.api.dto.HappLinkResult
import net.yukh.xui.data.api.dto.BulkDelRequest
import net.yukh.xui.data.api.dto.BulkDeleteResult
import net.yukh.xui.data.api.dto.BulkEmailsRequest
import net.yukh.xui.data.api.dto.ClientGroup
import net.yukh.xui.data.api.dto.ClientImportRequest
import net.yukh.xui.data.api.dto.ClientIpInfo
import net.yukh.xui.data.api.dto.GroupAddClientsRequest
import net.yukh.xui.data.api.dto.GroupNameRequest
import net.yukh.xui.data.api.dto.GroupRenameRequest
import net.yukh.xui.data.api.dto.VlessEncResponse
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import net.yukh.xui.data.api.dto.ApiToken
import net.yukh.xui.data.api.dto.Client
import net.yukh.xui.data.api.dto.ClientHwid
import net.yukh.xui.data.api.dto.ClientCreatePayload
import net.yukh.xui.data.api.dto.ClientModel
import net.yukh.xui.data.api.dto.EnableRequest
import net.yukh.xui.data.api.dto.InboundIdsRequest
import net.yukh.xui.data.api.dto.InboundModel
import net.yukh.xui.data.api.dto.InboundSlim
import net.yukh.xui.data.api.dto.MetricPoint
import net.yukh.xui.data.api.dto.MtlsCaResponse
import net.yukh.xui.data.api.dto.MtlsTrustCaRequest
import net.yukh.xui.data.api.dto.Node
import net.yukh.xui.data.api.dto.NodeIdsRequest
import net.yukh.xui.data.api.dto.NodeModel
import net.yukh.xui.data.api.dto.PanelSettings
import net.yukh.xui.data.api.dto.PanelUpdateInfo
import net.yukh.xui.data.api.dto.RouteTestResult
import net.yukh.xui.data.api.dto.ServerStatus
import net.yukh.xui.data.api.dto.OutboundSubscription
import net.yukh.xui.data.api.dto.SubInfo
import net.yukh.xui.data.api.dto.TestOutboundResult
import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Streaming
import retrofit2.http.Url

interface XuiApi {

    // ---- Server -----------------------------------------------------------

    @GET("panel/api/server/status")
    suspend fun getServerStatus(): ApiResponse<ServerStatus>

    // System-metrics history for the dashboard charts. metric ∈ SystemMetricKeys
    // (cpu, mem, swap, netUp, netDown, diskUsage, tcpCount, udpCount, load1…);
    // bucket ∈ {2, 30, 60, 120, 180, 300} seconds (≤ 60 points returned).
    @GET("panel/api/server/history/{metric}/{bucket}")
    suspend fun metricHistory(
        @Path("metric") metric: String,
        @Path("bucket") bucket: Int,
    ): ApiResponse<List<MetricPoint>>

    @POST("panel/api/server/restartXrayService")
    suspend fun restartXray(): ApiAck

    @POST("panel/api/server/stopXrayService")
    suspend fun stopXray(): ApiAck

    @GET("panel/api/server/getPanelUpdateInfo")
    suspend fun getPanelUpdateInfo(): ApiResponse<PanelUpdateInfo>

    // Generate VLESS-encryption key options (X25519 / ML-KEM-768 × native /
    // xorpub / random) via `xray vlessenc` (panel v3.4.1, xray-core v26.6.21+).
    @GET("panel/api/server/getNewVlessEnc")
    suspend fun getNewVlessEnc(): ApiResponse<VlessEncResponse>

    @POST("panel/api/server/updatePanel")
    suspend fun updatePanel(): ApiAck

    // Re-download one built-in geo database (allowlisted .dat name) from its
    // upstream release and restart Xray. The no-path variant updates all of
    // them at once.
    @POST("panel/api/server/updateGeofile/{fileName}")
    suspend fun updateGeofile(@Path("fileName") fileName: String): ApiAck

    @POST("panel/api/server/updateGeofile")
    suspend fun updateAllGeofiles(): ApiAck

    // ---- Backup / restore -------------------------------------------------

    // Download the panel database backup. Streaming; the engine-specific
    // filename (x-ui.db on SQLite, x-ui.dump on PostgreSQL) is returned in the
    // Content-Disposition header — the panel picks it, so the client stays
    // engine-agnostic.
    @Streaming
    @GET("panel/api/server/getDb")
    suspend fun getDb(): Response<ResponseBody>

    // Restore the panel from a backup file (multipart form field `db`). The
    // panel imports it (under its own engine) and restarts the Xray service.
    @Multipart
    @POST("panel/api/server/importDB")
    suspend fun importDb(@Part file: MultipartBody.Part): ApiAck

    // ---- Inbounds ---------------------------------------------------------

    // /list (not /list/slim): slim strips port/protocol/listen which the list
    // UI shows. The heavy settings JSON the full list adds is ignored.
    @GET("panel/api/inbounds/list")
    suspend fun listInbounds(): ApiResponse<List<InboundSlim>>

    @GET("panel/api/inbounds/get/{id}")
    suspend fun getInbound(@Path("id") id: Int): ApiResponse<InboundModel>

    @POST("panel/api/inbounds/add")
    suspend fun addInbound(@Body inbound: InboundModel): ApiAck

    @POST("panel/api/inbounds/update/{id}")
    suspend fun updateInbound(@Path("id") id: Int, @Body inbound: InboundModel): ApiAck

    @POST("panel/api/inbounds/del/{id}")
    suspend fun deleteInbound(@Path("id") id: Int): ApiAck

    @POST("panel/api/inbounds/setEnable/{id}")
    suspend fun setInboundEnable(
        @Path("id") id: Int,
        @Body body: EnableRequest,
    ): ApiAck

    // ---- Clients ----------------------------------------------------------

    @GET("panel/api/clients/list")
    suspend fun listClients(): ApiResponse<List<Client>>

    @POST("panel/api/clients/add")
    suspend fun addClient(@Body payload: ClientCreatePayload): ApiAck

    @POST("panel/api/clients/update/{email}")
    suspend fun updateClient(
        @Path("email") email: String,
        @Body client: ClientModel,
    ): ApiAck

    // obj is an array of subscription link strings, e.g. ["vless://…"].
    @GET("panel/api/clients/links/{email}")
    suspend fun getClientLinks(@Path("email") email: String): ApiResponse<List<String>>

    @POST("panel/api/clients/del/{email}")
    suspend fun deleteClient(@Path("email") email: String): ApiAck

    @POST("panel/api/clients/{email}/attach")
    suspend fun attachClient(
        @Path("email") email: String,
        @Body body: InboundIdsRequest,
    ): ApiAck

    @POST("panel/api/clients/{email}/detach")
    suspend fun detachClient(
        @Path("email") email: String,
        @Body body: InboundIdsRequest,
    ): ApiAck

    // Bulk actions over a set of client emails (panel v3.4.1).
    @POST("panel/api/clients/bulkEnable")
    suspend fun bulkEnableClients(@Body body: BulkEmailsRequest): ApiAck

    @POST("panel/api/clients/bulkDisable")
    suspend fun bulkDisableClients(@Body body: BulkEmailsRequest): ApiAck

    @POST("panel/api/clients/resetTraffic/{email}")
    suspend fun resetClientTraffic(@Path("email") email: String): ApiAck

    @POST("panel/api/clients/bulkResetTraffic")
    suspend fun bulkResetClientsTraffic(@Body body: BulkEmailsRequest): ApiAck

    // obj is the {adjusted, skipped[]} report on panels that send one.
    @POST("panel/api/clients/bulkAdjust")
    suspend fun bulkAdjustClients(@Body body: BulkAdjustRequest): ApiResponse<BulkAdjustResult>

    // Panel v3.8.0: an encrypted Happ link for the client with this record id. The
    // panel stores nothing; a disabled switch or any failure answers success=false.
    @POST("panel/api/clients/happLink/{id}")
    suspend fun happLink(@Path("id") id: Int): ApiResponse<HappLinkResult>

    @POST("panel/api/clients/bulkDel")
    suspend fun bulkDeleteClients(@Body body: BulkDelRequest): ApiAck

    // Same endpoint, read with the panel's {deleted, skipped[]} report.
    @POST("panel/api/clients/bulkDel")
    suspend fun bulkDeleteClientsWithReport(@Body body: BulkDelRequest): ApiResponse<BulkDeleteResult>

    // Client groups (panel v3.3.0; resetTraffic v3.4.2). Deleting a group keeps its clients.
    @GET("panel/api/clients/groups")
    suspend fun listClientGroups(): ApiResponse<List<ClientGroup>>

    @POST("panel/api/clients/groups/create")
    suspend fun createClientGroup(@Body body: GroupNameRequest): ApiAck

    @POST("panel/api/clients/groups/rename")
    suspend fun renameClientGroup(@Body body: GroupRenameRequest): ApiAck

    @POST("panel/api/clients/groups/delete")
    suspend fun deleteClientGroup(@Body body: GroupNameRequest): ApiAck

    @POST("panel/api/clients/groups/resetTraffic")
    suspend fun resetClientGroupTraffic(@Body body: GroupNameRequest): ApiAck

    @POST("panel/api/clients/groups/bulkAdd")
    suspend fun addClientsToGroup(@Body body: GroupAddClientsRequest): ApiAck

    @POST("panel/api/clients/groups/bulkRemove")
    suspend fun removeClientsFromGroup(@Body body: BulkEmailsRequest): ApiAck

    // Export/import all clients + delete unbound (orphan) clients (panel v3.4.0).
    @GET("panel/api/clients/export")
    suspend fun exportClients(): ApiResponse<JsonElement>

    @POST("panel/api/clients/import")
    suspend fun importClients(@Body body: ClientImportRequest): ApiAck

    @POST("panel/api/clients/delOrphans")
    suspend fun deleteOrphanClients(): ApiAck

    // A client's IP log (with connection time and node) + clear it (panel v3.4.0).
    @POST("panel/api/clients/ips/{email}")
    suspend fun getClientIps(@Path("email") email: String): ApiResponse<List<ClientIpInfo>>

    @POST("panel/api/clients/clearIps/{email}")
    suspend fun clearClientIps(@Path("email") email: String): ApiAck

    @POST("panel/api/clients/onlines")
    suspend fun listOnlines(): ApiResponse<List<String>>

    /** Panel v3.4.0+: returns {panelGuid → [emails]} — each online email appears under
     *  exactly one server's guid, so no email is double-counted across servers. */
    @POST("panel/api/clients/onlinesByGuid")
    suspend fun onlinesByGuid(): ApiResponse<Map<String, List<String>>>

    // ---- Nodes ------------------------------------------------------------

    @GET("panel/api/nodes/list")
    suspend fun listNodes(): ApiResponse<List<Node>>

    @POST("panel/api/nodes/add")
    suspend fun addNode(@Body node: NodeModel): ApiAck

    @POST("panel/api/nodes/update/{id}")
    suspend fun updateNode(@Path("id") id: Int, @Body node: NodeModel): ApiAck

    @POST("panel/api/nodes/del/{id}")
    suspend fun deleteNode(@Path("id") id: Int): ApiAck

    @POST("panel/api/nodes/setEnable/{id}")
    suspend fun setNodeEnable(@Path("id") id: Int, @Body body: EnableRequest): ApiAck

    // Trigger a 3x-ui self-update on the given node(s); the central panel relays
    // it to each node. Body: {"ids":[...]}.
    @POST("panel/api/nodes/updatePanel")
    suspend fun updateNodePanel(@Body body: NodeIdsRequest): ApiAck

    // Mutual-TLS between panels (panel v3.4.0): fetch this panel's CA to register
    // on a node, and set the CA whose client certs this panel trusts as a node.
    @POST("panel/api/nodes/mtls/ca")
    suspend fun nodeMtlsCa(): ApiResponse<MtlsCaResponse>

    @POST("panel/api/nodes/mtls/trustCA")
    suspend fun setNodeMtlsTrustCA(@Body body: MtlsTrustCaRequest): ApiAck

    // Panel v3.7.0: apply a rotated master mTLS credential without restarting
    // the panel — before this, a rotation needed a restart to take effect.
    @POST("panel/api/nodes/mtls/reloadClient")
    suspend fun reloadNodeMtlsClient(): ApiAck

    // ---- Settings & Xray config -------------------------------------------
    // Panel v3.3.0 (upstream c6f15cd5) moved these under /panel/api/* so they now
    // accept a Bearer token too (were session-only at /panel/setting/* and
    // /panel/xray/*, which v3.3.0 removed). Requires panel ≥ v3.3.0.

    @POST("panel/api/setting/all")
    suspend fun getAllSettings(): ApiResponse<PanelSettings>

    // Full panel settings as a raw object, for a read-modify-write round-trip
    // (setting/update overwrites every field, so we must resend the whole thing).
    @POST("panel/api/setting/all")
    suspend fun getAllSettingsRaw(): ApiResponse<JsonObject>


    // ---- Outbound subscriptions (panel v3.3.1+) --------------------------
    // Remote outbound lists the panel fetches and merges into the Xray config.
    // The handlers read form fields (c.PostForm), not JSON, so these are
    // @FormUrlEncoded; booleans arrive as the "true"/"false" the panel compares.

    @GET("panel/api/xray/outbound-subs")
    suspend fun listOutboundSubs(): ApiResponse<List<OutboundSubscription>>

    @FormUrlEncoded
    @POST("panel/api/xray/outbound-subs")
    suspend fun createOutboundSub(
        @Field("url") url: String,
        @Field("remark") remark: String,
        @Field("tagPrefix") tagPrefix: String,
        @Field("enabled") enabled: Boolean,
        @Field("updateInterval") updateInterval: Int,
        @Field("prepend") prepend: Boolean,
        @Field("allowPrivate") allowPrivate: Boolean,
        @Field("allowInsecure") allowInsecure: Boolean,
    ): ApiResponse<OutboundSubscription>

    @FormUrlEncoded
    @POST("panel/api/xray/outbound-subs/{id}")
    suspend fun updateOutboundSub(
        @Path("id") id: Int,
        @Field("url") url: String,
        @Field("remark") remark: String,
        @Field("tagPrefix") tagPrefix: String,
        @Field("enabled") enabled: Boolean,
        @Field("updateInterval") updateInterval: Int,
        @Field("prepend") prepend: Boolean,
        @Field("allowPrivate") allowPrivate: Boolean,
        @Field("allowInsecure") allowInsecure: Boolean,
    ): ApiAck

    // POST alias for DELETE — the panel offers it for clients that can't send DELETE.
    @POST("panel/api/xray/outbound-subs/{id}/del")
    suspend fun deleteOutboundSub(@Path("id") id: Int): ApiAck

    // Returns the freshly fetched outbounds; the panel also flags xray for restart.
    @POST("panel/api/xray/outbound-subs/{id}/refresh")
    suspend fun refreshOutboundSub(@Path("id") id: Int): ApiResponse<List<JsonObject>>

    @FormUrlEncoded
    @POST("panel/api/xray/outbound-subs/{id}/move")
    suspend fun moveOutboundSub(@Path("id") id: Int, @Field("dir") dir: String): ApiAck

    // Fetch + parse a URL without saving anything, to preview what it yields.
    @FormUrlEncoded
    @POST("panel/api/xray/outbound-subs/parse")
    suspend fun parseOutboundSub(
        @Field("url") url: String,
        @Field("allowPrivate") allowPrivate: Boolean,
        @Field("allowInsecure") allowInsecure: Boolean,
    ): ApiResponse<List<JsonObject>>

    @POST("panel/api/setting/update")
    suspend fun updateSettings(@Body settings: JsonObject): ApiAck

    // Subscription server's live-status snapshot (panel v3.6.0+). Takes the full
    // absolute sub URL + "?format=info"; the sub server may live on a different
    // host/port than the panel API, so this is an absolute @Url, not a base path.
    // Returns a bare object (no {success,obj} envelope) unlike the panel API.
    @GET
    suspend fun subInfo(@Url url: String): SubInfo

    /** Returns the wrapped config as a JSON string in `obj` (parse twice). */
    @POST("panel/api/xray/")
    suspend fun getXraySetting(): ApiResponse<String>

    @FormUrlEncoded
    @POST("panel/api/xray/update")
    suspend fun updateXraySetting(
        @Field("xraySetting") xraySetting: String,
        @Field("outboundTestUrl") outboundTestUrl: String,
    ): ApiAck

    // Probes one outbound; the panel supplies the test URL server-side (SSRF-safe).
    // mode: "tcp" (dial only), "http" (request through xray), "real" (full real delay).
    @FormUrlEncoded
    @POST("panel/api/xray/testOutbound")
    suspend fun testOutbound(
        @Field("outbound") outbound: String,
        @Field("mode") mode: String,
    ): ApiResponse<TestOutboundResult>

    // Resolves which outbound a destination routes to against the live config.
    // Empty port/network mean "any"; at least one of domain/ip must be set.
    @FormUrlEncoded
    @POST("panel/api/xray/routeTest")
    suspend fun routeTest(
        @Field("domain") domain: String,
        @Field("ip") ip: String,
        @Field("port") port: String,
        @Field("network") network: String,
        @Field("inboundTag") inboundTag: String,
    ): ApiResponse<RouteTestResult>

    // ---- Panel admin (settings) -------------------------------------------

    // Change the admin username + password. The panel verifies the old
    // credentials against the logged-in (token → first admin) user.
    @FormUrlEncoded
    @POST("panel/api/setting/updateUser")
    suspend fun updateUser(
        @Field("oldUsername") oldUsername: String,
        @Field("oldPassword") oldPassword: String,
        @Field("newUsername") newUsername: String,
        @Field("newPassword") newPassword: String,
    ): ApiAck

    // Restart the panel service (after a short delay) — the app's connection
    // drops briefly while it comes back.
    @POST("panel/api/setting/restartPanel")
    suspend fun restartPanel(): ApiAck

    // ---- Subscription devices (HWID, panel v3.7.0) -----------------------
    // The panel counts registered devices against the client's HWID limit.
    // Listing is a POST (the panel's own convention for read endpoints that
    // take a path parameter); removal is a real DELETE.

    @POST("panel/api/clients/hwids/{email}")
    suspend fun listClientHwids(@Path("email") email: String): ApiResponse<List<ClientHwid>>

    @DELETE("panel/api/clients/hwids/{email}")
    suspend fun clearClientHwids(@Path("email") email: String): ApiAck

    @DELETE("panel/api/clients/hwids/{email}/{id}")
    suspend fun deleteClientHwid(@Path("email") email: String, @Path("id") id: Int): ApiAck

    @GET("panel/api/setting/apiTokens")
    suspend fun listApiTokens(): ApiResponse<List<ApiToken>>

    // Returns the new token with its plaintext value (shown only once).
    // scope/expiresAt are panel v3.7.0 fields; older panels ignore the extra
    // form values and keep minting full-access tokens.
    @FormUrlEncoded
    @POST("panel/api/setting/apiTokens/create")
    suspend fun createApiToken(
        @Field("name") name: String,
        @Field("scope") scope: String,
        @Field("expiresAt") expiresAt: Long,
    ): ApiResponse<ApiToken>

    // expectedScope is REQUIRED from panel v3.7.0: the panel refuses to delete
    // or toggle a token unless the caller names the scope it thinks it has, so
    // a stale list cannot revoke the wrong token.
    @FormUrlEncoded
    @POST("panel/api/setting/apiTokens/delete/{id}")
    suspend fun deleteApiToken(
        @Path("id") id: Int,
        @Field("expectedScope") expectedScope: String,
    ): ApiAck

    @FormUrlEncoded
    @POST("panel/api/setting/apiTokens/setEnabled/{id}")
    suspend fun setApiTokenEnabled(
        @Path("id") id: Int,
        @Field("enabled") enabled: Boolean,
        @Field("expectedScope") expectedScope: String,
    ): ApiAck
}
