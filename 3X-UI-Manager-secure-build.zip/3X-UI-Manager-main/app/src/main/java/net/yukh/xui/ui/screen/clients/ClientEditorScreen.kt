package net.yukh.xui.ui.screen.clients

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import net.yukh.xui.i18n.LocalAppLanguage
import net.yukh.xui.i18n.tr
import net.yukh.xui.ui.components.ConfirmDialog
import net.yukh.xui.ui.components.EditableDropdownField
import net.yukh.xui.ui.format.formatDateTime
import net.yukh.xui.ui.format.formatDateTimeInZone
import net.yukh.xui.ui.format.localZoneLabel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ClientEditorScreen(
    state: ClientEditorState,
    onEmail: (String) -> Unit,
    onEnable: (Boolean) -> Unit,
    onLimitIp: (String) -> Unit,
    onTotalGb: (String) -> Unit,
    onReset: (String) -> Unit,
    onResetDay: (String) -> Unit,
    onResetMax: (String) -> Unit,
    onTrafficReset: (String) -> Unit,
    onTrafficResetDay: (String) -> Unit,
    onLimitHwid: (String) -> Unit,
    onForwardedPorts: (String) -> Unit,
    onShowDevices: () -> Unit,
    onTgId: (String) -> Unit,
    onGroup: (String) -> Unit,
    onComment: (String) -> Unit,
    onAdTag: (String) -> Unit,
    onRegenerateSecret: () -> Unit,
    onAllowedIps: (String) -> Unit,
    onKeepAlive: (String) -> Unit,
    onExpiry: (Long) -> Unit,
    onToggleInbound: (Int) -> Unit,
    onSave: () -> Unit,
    onClose: () -> Unit,
) {
    var showDatePicker by remember { mutableStateOf(false) }
    // Date and time are picked in two steps; this holds the chosen day (UTC
    // midnight, as the date picker reports it) while the time is chosen.
    var pendingDateMillis by remember { mutableStateOf<Long?>(null) }
    var confirmSave by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize().imePadding(),
        topBar = {
            TopAppBar(
                title = { Text(if (state.isNew) tr("New client") else tr("Edit client")) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr("Cancel"))
                    }
                },
                actions = {
                    TextButton(onClick = { confirmSave = true }, enabled = state.canSave) {
                        if (state.saving) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Text(tr("Save"))
                        }
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = state.email,
                onValueChange = onEmail,
                label = { Text(tr("Email / name")) },
                singleLine = true,
                isError = state.masqueEmailInvalid,
                supportingText = if (state.masqueEmailInvalid) {
                    { Text(tr("MASQUE: client email cannot contain \":\"")) }
                } else {
                    null
                },
                modifier = Modifier.fillMaxWidth(),
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(tr("Enabled"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Switch(checked = state.enable, onCheckedChange = onEnable)
            }

            HorizontalDivider()

            // Inbound membership — editable on both create and edit (the toggles
            // diff against the client's current inbounds and attach/detach on save).
            Text(tr("Inbounds"), style = MaterialTheme.typography.titleSmall)
            if (state.inboundsLoading) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.availableInbounds.forEach { ib ->
                        val selected = ib.id in state.selectedInboundIds
                        FilterChip(
                            selected = selected,
                            onClick = { onToggleInbound(ib.id) },
                            label = {
                                Text(ib.remark.ifBlank { "#${ib.id}" } + " · ${ib.protocol}")
                            },
                        )
                    }
                }
            }

            HorizontalDivider()

            OutlinedTextField(
                value = state.totalGb,
                onValueChange = onTotalGb,
                label = { Text(tr("Traffic limit (GB, 0 = unlimited)")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
            )

            OutlinedTextField(
                value = state.limitIp,
                onValueChange = onLimitIp,
                label = { Text(tr("IP limit (0 = unlimited)")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )

            if (state.isTuic) {
                Text(
                    tr("On a TUIC inbound the panel can't enforce a per-client traffic limit or IP limit — limit traffic on the TUIC inbound itself."),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            OutlinedTextField(
                value = state.reset,
                onValueChange = onReset,
                label = { Text(tr("Traffic reset period (days, 0 = off)")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )

            if (state.weeklyRenewal) {
                Text(
                    tr("Weekly renewal is on (set in the web panel). A reset period or a renewal day turns it off."),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            // ---- Renewal, reset cycle and devices (panel v3.7.0) ----
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = state.resetDay,
                    onValueChange = onResetDay,
                    label = { Text(tr("Renew on day (0 = interval)")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = state.resetMax,
                    onValueChange = onResetMax,
                    label = { Text(tr("Max renewals (0 = ∞)")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    EditableDropdownField(
                        label = tr("Traffic reset cycle"),
                        value = state.trafficReset,
                        options = TRAFFIC_RESET_CYCLES,
                        onChange = onTrafficReset,
                    )
                }
                if (state.trafficReset == "monthly") {
                    OutlinedTextField(
                        value = state.trafficResetDay,
                        onValueChange = onTrafficResetDay,
                        label = { Text(tr("Day")) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = state.limitHwid,
                    onValueChange = onLimitHwid,
                    label = { Text(tr("Device limit (0 = unlimited)")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                if (!state.isNew) {
                    OutlinedButton(onClick = onShowDevices) { Text(tr("Devices")) }
                }
            }

            if (state.isAmneziawg) {
                OutlinedTextField(
                    value = state.forwardedPorts,
                    onValueChange = onForwardedPorts,
                    label = { Text(tr("Forwarded ports")) },
                    placeholder = { Text("80, 443, 8000-8100") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                Text(tr("Expiry"), style = MaterialTheme.typography.labelMedium)
                Text(state.expiryTime.formatDateTime(LocalAppLanguage.current), style = MaterialTheme.typography.bodyLarge)
                if (state.expiryTime > 0) {
                    // Whose clock this is, spelled out: the panel may well sit in
                    // another zone than the phone it is managed from.
                    Text(
                        state.expiryTime.localZoneLabel() + " · " + tr("your phone"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    state.expiryTime.formatDateTimeInZone(state.panelTimeZone)?.let { onPanel ->
                        Text(
                            "${tr("On the panel")}: $onPanel (${state.panelTimeZone})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                // Own line for the buttons: sharing a Row with this column squeezed it to a
                // sliver once "Never" appeared, and the wrapped text blew the row up.
                FlowRow(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (state.expiryTime != 0L) {
                        OutlinedButton(onClick = { onExpiry(0) }) { Text(tr("Never")) }
                    }
                    Button(onClick = { showDatePicker = true }) { Text(tr("Pick date & time")) }
                }
            }

            OutlinedTextField(
                value = state.tgId,
                onValueChange = onTgId,
                label = { Text(tr("Telegram ID (optional)")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )

            EditableDropdownField(
                label = tr("Group (optional)"),
                value = state.group,
                options = state.availableGroups,
                onChange = onGroup,
            )

            OutlinedTextField(
                value = state.comment,
                onValueChange = onComment,
                label = { Text(tr("Comment (optional)")) },
                modifier = Modifier.fillMaxWidth(),
            )

            if (state.isMtproto) {
                OutlinedTextField(
                    value = state.secret,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(tr("MTProto secret")) },
                    trailingIcon = {
                        IconButton(onClick = onRegenerateSecret) {
                            Icon(Icons.Filled.Refresh, contentDescription = tr("Regenerate"))
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = state.adTag,
                    onValueChange = onAdTag,
                    label = { Text(tr("Ad-tag (sponsored channel, 32 hex)")) },
                    isError = state.adTag.isNotEmpty() && state.adTag.length != 32,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            if (state.isWireguard) {
                OutlinedTextField(
                    value = state.allowedIps,
                    onValueChange = onAllowedIps,
                    label = { Text(tr("WireGuard allowed IPs")) },
                    placeholder = { Text("10.0.0.2/32") },
                    supportingText = { Text(tr("Comma-separated; leave empty to auto-assign.")) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            if (state.isWireguard || state.isAmneziawg) {
                OutlinedTextField(
                    value = state.keepAlive,
                    onValueChange = onKeepAlive,
                    label = { Text(tr("Keepalive (seconds)")) },
                    isError = state.keepAliveInvalid,
                    supportingText = {
                        Text(
                            when {
                                !state.keepAliveInvalid && state.keepAliveRangeAllowed ->
                                    tr("Seconds or a range such as 15-25, from 0 to 65535. 25 keeps NAT open; 0 turns it off.")
                                !state.keepAliveInvalid ->
                                    tr("How often the client sends a keepalive. 25 keeps NAT open and brings an idle peer back after any drop; 0 turns it off.")
                                '-' in state.keepAlive && !state.keepAliveRangeAllowed ->
                                    tr("A keepalive range works only for AmneziaWG; WireGuard takes whole seconds.")
                                state.keepAliveRangeAllowed -> tr("Enter a whole number or range from 0 to 65535.")
                                else -> tr("Enter a whole number from 0 to 65535.")
                            },
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (state.keepAliveRangeAllowed) KeyboardType.Phone else KeyboardType.Number,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }

    if (confirmSave) {
        ConfirmDialog(
            title = if (state.isNew) tr("Create client?") else tr("Save changes?"),
            text = if (state.isNew) "${tr("Create client")} \"${state.email}\"?"
            else "${tr("Apply changes to")} \"${state.email}\"?",
            confirmLabel = if (state.isNew) tr("Create") else tr("Save"),
            onConfirm = onSave,
            onDismiss = { confirmSave = false },
        )
    }

    if (showDatePicker) {
        ExpiryDatePickerDialog(
            initialMillis = state.expiryTime.takeIf { it > 0 },
            onPick = { showDatePicker = false; pendingDateMillis = it },
            onDismiss = { showDatePicker = false },
        )
    }

    pendingDateMillis?.let { dayMillis ->
        ExpiryTimePickerDialog(
            initialMillis = state.expiryTime.takeIf { it > 0 },
            onPick = { hour, minute ->
                onExpiry(combineExpiry(dayMillis, hour, minute))
                pendingDateMillis = null
            },
            onDismiss = { pendingDateMillis = null },
        )
    }
}

/**
 * Combine the day the date picker reported (UTC midnight) with a wall-clock time
 * into an instant in the phone's own time zone — which is how the panel reads
 * and shows the value. Taking the picker's millis as-is would pin every expiry
 * to midnight UTC and, west of Greenwich, show the previous day.
 */
private fun combineExpiry(dayUtcMillis: Long, hour: Int, minute: Int): Long {
    val utc = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
    utc.timeInMillis = dayUtcMillis
    val local = java.util.Calendar.getInstance()
    local.set(
        utc.get(java.util.Calendar.YEAR),
        utc.get(java.util.Calendar.MONTH),
        utc.get(java.util.Calendar.DAY_OF_MONTH),
        hour,
        minute,
        0,
    )
    local.set(java.util.Calendar.MILLISECOND, 0)
    return local.timeInMillis
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExpiryTimePickerDialog(
    initialMillis: Long?,
    onPick: (Int, Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val calendar = java.util.Calendar.getInstance().apply {
        // An expiry the operator hasn't timed yet ends the day rather than
        // starting it: 23:59 is what "expires on that date" means to a customer.
        if (initialMillis != null && initialMillis > 0) {
            timeInMillis = initialMillis
        } else {
            set(java.util.Calendar.HOUR_OF_DAY, 23)
            set(java.util.Calendar.MINUTE, 59)
        }
    }
    val pickerState = androidx.compose.material3.rememberTimePickerState(
        initialHour = calendar.get(java.util.Calendar.HOUR_OF_DAY),
        initialMinute = calendar.get(java.util.Calendar.MINUTE),
        is24Hour = true,
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Expiry time")) },
        text = { androidx.compose.material3.TimePicker(state = pickerState) },
        confirmButton = {
            TextButton(onClick = { onPick(pickerState.hour, pickerState.minute) }) { Text(tr("OK")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExpiryDatePickerDialog(
    initialMillis: Long?,
    onPick: (Long) -> Unit,
    onDismiss: () -> Unit,
) {
    val pickerState = androidx.compose.material3.rememberDatePickerState(
        initialSelectedDateMillis = initialMillis,
    )
    androidx.compose.material3.DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { pickerState.selectedDateMillis?.let(onPick) }) { Text(tr("OK")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } },
    ) {
        androidx.compose.material3.DatePicker(state = pickerState)
    }
}


/** Panel-side cycles for a client's own traffic reset (panel v3.7.0). */
private val TRAFFIC_RESET_CYCLES = listOf("never", "hourly", "daily", "weekly", "monthly")
