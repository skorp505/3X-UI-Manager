package net.yukh.xui.data.api.dto

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

/**
 * Row in GET /panel/api/clients/list on 3x-ui v3.x.
 *
 * Traffic counters live in the nested `traffic` object, NOT at the top
 * level. `tgId` is a numeric Telegram user id (0 when unset) — it is a
 * JSON number, not a string. `inboundIds` lists every inbound the client
 * is attached to.
 */
@Serializable
data class Client(
    val id: Int = 0,
    val email: String = "",
    val uuid: String = "",
    val subId: String = "",
    val flow: String = "",
    val security: String = "",
    val password: String = "",
    val auth: String = "",
    // MTProto (panel 3.5.0): FakeTLS secret + optional advertising tag.
    val secret: String = "",
    val adTag: String = "",
    // WireGuard peer fields — kept so editing a WG client doesn't drop them.
    // NOTE: /clients/list serializes allowedIPs as a comma-separated STRING
    // (the wg_allowed_ips column), unlike the create/update payload which is an
    // array — so it's a String here and split into a list in toModel().
    val privateKey: String = "",
    val publicKey: String = "",
    val preSharedKey: String = "",
    val allowedIPs: String = "",
    @Serializable(with = KeepAliveSerializer::class)
    val keepAlive: String = "",
    val enable: Boolean = true,
    val tgId: Long = 0,
    val limitIp: Int = 0,
    val totalGB: Long = 0,
    val expiryTime: Long = 0,
    val reset: Int = 0,
    // Panel v3.7.0: calendar-day renewal + a cap on auto-renewals, the client's
    // own traffic-reset cycle, the subscription device limit, and AmneziaWG
    // forwarded ports.
    val resetDay: Int = 0,
    val resetMax: Int = 0,
    // Panel v3.9.0 weekly renewal (1-7 = Mon-Sun, 0 = off) and the VLESS simple
    // reverse proxy ({"tag":…} or null). The panel's update overwrites both from the body.
    val resetWeekday: Int = 0,
    val reverse: JsonElement? = null,
    val trafficReset: String = "never",
    val trafficResetDay: Int = 1,
    val limitHwid: Int = 0,
    val forwardedPorts: String = "",
    val group: String = "",
    val comment: String = "",
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    val inboundIds: List<Int> = emptyList(),
    val traffic: ClientStat? = null,
) {
    val up: Long get() = traffic?.up ?: 0
    val down: Long get() = traffic?.down ?: 0
    /** Quota in bytes; 0 means unlimited. Prefer the traffic counter, fall back to totalGB. */
    val quota: Long get() = traffic?.total?.takeIf { it > 0 } ?: totalGB
    val lastOnline: Long get() = traffic?.lastOnline ?: 0

    /**
     * Rebuild the model.Client shape the panel expects for create/update.
     * The panel's `id` field is the protocol UUID (our `uuid`), NOT the
     * record id. Carries password/auth/security forward so an update of one
     * field doesn't blank the credentials.
     */
    fun toModel(): ClientModel = ClientModel(
        id = uuid,
        email = email,
        password = password,
        auth = auth,
        secret = secret,
        adTag = adTag,
        privateKey = privateKey,
        publicKey = publicKey,
        preSharedKey = preSharedKey,
        allowedIPs = allowedIPs.split(",").map { it.trim() }.filter { it.isNotEmpty() },
        keepAlive = keepAlive.takeIf { it.isNotEmpty() && it != "0" },
        security = security,
        flow = flow,
        limitIp = limitIp,
        totalGB = totalGB,
        expiryTime = expiryTime,
        enable = enable,
        tgId = tgId,
        subId = subId,
        group = group,
        comment = comment,
        reset = reset,
        resetDay = resetDay,
        resetMax = resetMax,
        resetWeekday = resetWeekday,
        reverse = reverseObject(reverse),
        trafficReset = trafficReset,
        trafficResetDay = trafficResetDay,
        limitHwid = limitHwid,
        forwardedPorts = forwardedPorts,
        createdAt = createdAt,
        updatedAt = updatedAt,
    )
}

/** The stored reverse as the object the update body takes; an empty or tag-less one
 *  is dropped (the panel clears it either way). Older panels sent it as JSON text. */
private fun reverseObject(raw: JsonElement?): JsonObject? {
    val obj = when (raw) {
        is JsonObject -> raw
        is JsonPrimitive -> raw.contentOrNull?.takeIf { raw.isString && it.isNotBlank() }
            ?.let { runCatching { Json.parseToJsonElement(it) as? JsonObject }.getOrNull() }
        else -> null
    } ?: return null
    val tag = runCatching { obj["tag"]?.jsonPrimitive?.contentOrNull }.getOrNull()
    return obj.takeIf { !tag.isNullOrBlank() }
}
