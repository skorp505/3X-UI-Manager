package net.yukh.xui.ui.screen.clients

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.serialization.json.Json
import net.yukh.xui.data.api.dto.Client
import net.yukh.xui.data.api.dto.isValidBulkAdTag
import net.yukh.xui.i18n.LocalAppLanguage
import net.yukh.xui.i18n.tr
import net.yukh.xui.ui.components.ExportJsonDialog
import net.yukh.xui.ui.components.ImportJsonDialog
import net.yukh.xui.ui.components.LabeledDropdown
import net.yukh.xui.ui.format.formatBytes
import net.yukh.xui.ui.format.formatDate
import net.yukh.xui.ui.format.formatSpeed
import net.yukh.xui.ui.format.formatExpiryDays
import net.yukh.xui.ui.format.formatLastOnline

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientsScreen(
    onOpenGroups: () -> Unit = {},
    vm: ClientsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val filterSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showFilters by remember { mutableStateOf(false) }
    var showAdjust by remember { mutableStateOf(false) }
    var confirmBulkDelete by remember { mutableStateOf(false) }
    var confirmBulkReset by remember { mutableStateOf(false) }
    var clientsMenu by remember { mutableStateOf(false) }
    var showImportClients by remember { mutableStateOf(false) }
    var confirmDeleteOrphans by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.load() }

    // Auto-refresh the list while the screen is on-screen (start/stop with lifecycle).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> vm.startPolling()
                Lifecycle.Event.ON_STOP -> vm.stopPolling()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer); vm.stopPolling() }
    }

    // Hardware back exits selection mode first.
    BackHandler(enabled = state.selectionMode) { vm.exitSelection() }

    LaunchedEffect(state.transientMessage) {
        state.transientMessage?.let {
            snackbarHostState.showSnackbar(it)
            vm.dismissMessage()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when {
            state.loading -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) { CircularProgressIndicator() }

            state.error != null && state.items.isEmpty() -> Box(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    state.error.orEmpty(),
                    color = MaterialTheme.colorScheme.error,
                )
            }

            state.items.isEmpty() -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) { Text(tr("No clients yet.")) }

            else -> Column(modifier = Modifier.fillMaxSize()) {
                if (state.selectionMode) {
                    SelectionBar(
                        count = state.selectedEmails.size,
                        busy = state.bulkInFlight,
                        onClose = vm::exitSelection,
                        onSelectAll = vm::selectAllVisible,
                        onEnable = { vm.bulkSetEnabled(true) },
                        onDisable = { vm.bulkSetEnabled(false) },
                        onAdjust = { showAdjust = true },
                        onResetTraffic = { confirmBulkReset = true },
                        onDelete = { confirmBulkDelete = true },
                    )
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        OutlinedTextField(
                            value = state.searchQuery,
                            onValueChange = vm::setSearchQuery,
                            label = { Text(tr("Search email, ID, UUID…"), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            trailingIcon = {
                                if (state.searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { vm.setSearchQuery("") }) {
                                        Icon(Icons.Filled.Clear, contentDescription = tr("Clear"))
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { showFilters = true }) {
                            BadgedBox(
                                badge = {
                                    if (state.filters.count > 0) Badge { Text(state.filters.count.toString()) }
                                },
                            ) {
                                Icon(Icons.Filled.FilterList, contentDescription = tr("Filters"))
                            }
                        }
                        Box {
                            IconButton(onClick = { clientsMenu = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = tr("More"))
                            }
                            DropdownMenu(expanded = clientsMenu, onDismissRequest = { clientsMenu = false }) {
                                DropdownMenuItem(text = { Text(tr("Groups")) }, onClick = { clientsMenu = false; onOpenGroups() })
                                DropdownMenuItem(text = { Text(tr("Export clients")) }, onClick = { clientsMenu = false; vm.exportClients() })
                                DropdownMenuItem(text = { Text(tr("Import clients")) }, onClick = { clientsMenu = false; showImportClients = true })
                                DropdownMenuItem(text = { Text(tr("Delete unbound clients")) }, onClick = { clientsMenu = false; confirmDeleteOrphans = true })
                            }
                        }
                    }
                }

                val visible = state.visibleItems
                if (visible.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            if (state.searchQuery.isNotBlank())
                                "${tr("No clients match")} \"${state.searchQuery}\"."
                            else tr("No clients match the filters"),
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(visible, key = { it.email.ifBlank { it.id.toString() } }) { client ->
                            ClientRow(
                                client = client,
                                speed = state.speedByClient[client.email],
                                online = client.email in state.online,
                                selected = client.email in state.selectedEmails,
                                selectionMode = state.selectionMode,
                                onClick = {
                                    if (state.selectionMode) vm.toggleSelected(client.email)
                                    else vm.openShareSheet(client.email)
                                },
                                onLongClick = { vm.startSelection(client.email) },
                                onToggleEnabled = { vm.toggleClientEnabled(client.email, it) },
                            )
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = vm::openCreateEditor,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
        ) {
            Icon(Icons.Filled.Add, contentDescription = tr("Add client"))
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter),
        ) { Snackbar { Text(it.visuals.message) } }
    }

    val selectedEmail = state.selectedClientEmail
    if (selectedEmail != null) {
        ClientShareSheet(
            email = selectedEmail,
            links = state.selectedLinks,
            loading = state.linksLoading,
            error = state.linksError,
            subUrl = state.selectedSubUrl,
            jsonSubUrl = state.selectedJsonSubUrl,
            subChecked = state.subUrlChecked,
            subInfo = state.selectedSubInfo,
            happLinkEnabled = state.happLinkEnabled,
            happLink = state.happLink,
            happLinkLoading = state.happLinkLoading,
            happLinkError = state.happLinkError,
            onGenerateHappLink = vm::generateHappLink,
            sheetState = sheetState,
            onDismiss = vm::closeShareSheet,
            onEdit = { vm.openEditEditor(selectedEmail) },
            onDelete = { vm.deleteClient(selectedEmail) },
            onIpLog = { vm.openIpLog(selectedEmail); vm.closeShareSheet() },
            onResetTraffic = { vm.resetClientTraffic(selectedEmail) },
        )
    }

    state.ipLogEmail?.let { email ->
        AlertDialog(
            onDismissRequest = vm::closeIpLog,
            title = { Text("${tr("IP log")} · $email") },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    when {
                        state.ipLogLoading -> CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        state.ipLog.isEmpty() -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(tr("No IPs logged."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                tr("The panel keeps an address for 30 minutes after the last connection, so this stays empty for anyone who hasn't connected recently."),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        else -> state.ipLog.forEach { e ->
                            Column {
                                Text(e.ip, style = MaterialTheme.typography.bodyMedium)
                                val sub = listOfNotNull(
                                    e.time.takeIf { it.isNotBlank() },
                                    e.node.takeIf { it.isNotBlank() }?.let { "@ $it" },
                                ).joinToString("  ")
                                if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = vm::clearIpLog, enabled = state.ipLog.isNotEmpty()) { Text(tr("Clear")) }
            },
            dismissButton = { TextButton(onClick = vm::closeIpLog) { Text(tr("Close")) } },
        )
    }

    state.hwidEmail?.let { email ->
        AlertDialog(
            onDismissRequest = vm::closeHwids,
            title = { Text("${tr("Devices")} · $email") },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    when {
                        state.hwidsLoading -> CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        state.hwidsUnsupported -> Text(
                            tr("Your panel version doesn't support this yet. Update the panel to the latest version to use it."),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        state.hwids.isEmpty() -> Text(tr("No devices registered."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else -> state.hwids.forEach { d ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(d.label.ifBlank { "#${d.id}" }, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "${tr("Last seen")}: ${d.lastSeen.formatDate(LocalAppLanguage.current)}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    if (d.fingerprint.isNotBlank()) {
                                        Text(
                                            "${tr("Device fingerprint")}: ${d.fingerprint}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                                TextButton(onClick = { vm.removeHwid(d.id) }) { Text(tr("Remove")) }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = vm::clearHwids, enabled = state.hwids.isNotEmpty()) { Text(tr("Clear")) }
            },
            dismissButton = { TextButton(onClick = vm::closeHwids) { Text(tr("Close")) } },
        )
    }

    if (showFilters) {
        ClientFilterSheet(
            filters = state.filters,
            groups = state.allGroups,
            sheetState = filterSheetState,
            onToggleStatus = vm::toggleStatusFilter,
            onToggleGroup = vm::toggleGroupFilter,
            onClear = vm::clearFilters,
            onDismiss = { showFilters = false },
        )
    }

    if (showAdjust) {
        BulkAdjustDialog(
            count = state.selectedEmails.size,
            panel380 = state.panel380,
            onApply = { addDays, addBytes, flow, limitHwid, adTag ->
                vm.bulkAdjust(addDays, addBytes, flow, limitHwid, adTag)
                showAdjust = false
            },
            onDismiss = { showAdjust = false },
        )
    }

    if (confirmBulkReset) {
        AlertDialog(
            onDismissRequest = { confirmBulkReset = false },
            title = { Text(tr("Reset traffic of the selected clients?")) },
            text = {
                Text(
                    "${state.selectedEmails.size} ${tr("selected")}\n\n" +
                        tr("Used traffic starts from zero, and a client its quota switched off is enabled again."),
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.bulkResetTraffic(); confirmBulkReset = false }) {
                    Text(tr("Reset traffic"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmBulkReset = false }) { Text(tr("Cancel")) } },
        )
    }

    if (confirmBulkDelete) {
        AlertDialog(
            onDismissRequest = { confirmBulkDelete = false },
            title = { Text(tr("Delete selected clients?")) },
            text = { Text("${state.selectedEmails.size} ${tr("selected")}") },
            confirmButton = {
                TextButton(onClick = { vm.bulkDelete(); confirmBulkDelete = false }) {
                    Text(tr("Delete"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmBulkDelete = false }) { Text(tr("Cancel")) } },
        )
    }

    state.exportJson?.let { json ->
        ExportJsonDialog(title = tr("Export clients"), json = json, onDismiss = vm::dismissExport)
    }

    if (showImportClients) {
        val invalidMsg = tr("Invalid JSON")
        ImportJsonDialog(
            title = tr("Import clients"),
            onImport = { txt ->
                if (runCatching { Json.parseToJsonElement(txt.trim()) }.isFailure) invalidMsg
                else { vm.importClients(txt.trim()); null }
            },
            onDismiss = { showImportClients = false },
        )
    }

    if (confirmDeleteOrphans) {
        AlertDialog(
            onDismissRequest = { confirmDeleteOrphans = false },
            title = { Text(tr("Delete unbound clients?")) },
            text = { Text(tr("Removes every client not attached to any inbound, with their traffic and links. This can't be undone.")) },
            confirmButton = {
                TextButton(onClick = { vm.deleteOrphanClients(); confirmDeleteOrphans = false }) {
                    Text(tr("Delete"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteOrphans = false }) { Text(tr("Cancel")) } },
        )
    }

    // The client editor is rendered as a full-screen overlay by MainScreen
    // (activity window) so its insets/keyboard handling work correctly.
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ClientRow(
    client: Client,
    speed: Pair<Long, Long>?,
    online: Boolean,
    selected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        colors = CardDefaults.cardColors(
            containerColor = when {
                selected -> MaterialTheme.colorScheme.primaryContainer
                client.enable -> MaterialTheme.colorScheme.surfaceVariant
                else -> MaterialTheme.colorScheme.surface
            },
        ),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectionMode) {
                    Checkbox(
                        checked = selected,
                        onCheckedChange = { onClick() },
                        modifier = Modifier.padding(end = 4.dp),
                    )
                }
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(
                            // Online = clear green; offline = muted gray.
                            color = if (online) Color(0xFF34C759)
                            else MaterialTheme.colorScheme.outline,
                            shape = CircleShape,
                        ),
                )
                Text(
                    text = client.email.ifBlank { tr("(no email)") },
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (!selectionMode) {
                    Switch(
                        checked = client.enable,
                        onCheckedChange = onToggleEnabled,
                        modifier = Modifier.padding(start = 4.dp),
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("↑ ${client.up.formatBytes()}", style = MaterialTheme.typography.labelMedium)
                Text("↓ ${client.down.formatBytes()}", style = MaterialTheme.typography.labelMedium)
                if (client.quota > 0) {
                    Text(
                        "${tr("of")} ${client.quota.formatBytes()}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (speed != null && (speed.first > 0 || speed.second > 0)) {
                Text(
                    "↑ ${formatSpeed(speed.first, net.yukh.xui.ui.format.LocalSpeedInBits.current)}   ↓ ${formatSpeed(speed.second, net.yukh.xui.ui.format.LocalSpeedInBits.current)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Text(
                "${tr("Expires")}: ${client.expiryTime.formatExpiryDays(LocalAppLanguage.current)}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val lastSeen = if (client.lastOnline <= 0L) tr("Never")
                else client.lastOnline.formatLastOnline(LocalAppLanguage.current)
            Text(
                "${tr("Last seen")}: $lastSeen",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    busy: Boolean,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onEnable: () -> Unit,
    onDisable: () -> Unit,
    onAdjust: () -> Unit,
    onResetTraffic: () -> Unit,
    onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = tr("Cancel")) }
        Text(
            "$count ${tr("selected")}",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.weight(1f),
        )
        if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        IconButton(onClick = onSelectAll) { Icon(Icons.Filled.DoneAll, contentDescription = tr("Select all")) }
        Box {
            IconButton(onClick = { menu = true }, enabled = !busy) {
                Icon(Icons.Filled.MoreVert, contentDescription = tr("More"))
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(tr("Enable")) }, onClick = { menu = false; onEnable() })
                DropdownMenuItem(text = { Text(tr("Disable")) }, onClick = { menu = false; onDisable() })
                DropdownMenuItem(text = { Text(tr("Adjust") + "…") }, onClick = { menu = false; onAdjust() })
                DropdownMenuItem(text = { Text(tr("Reset traffic")) }, onClick = { menu = false; onResetTraffic() })
                DropdownMenuItem(text = { Text(tr("Delete")) }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
private fun BulkAdjustDialog(
    count: Int,
    panel380: Boolean,
    onApply: (Int, Long, String, Int?, String) -> Unit,
    onDismiss: () -> Unit,
) {
    var days by remember { mutableStateOf("") }
    var gb by remember { mutableStateOf("") }
    var flow by remember { mutableStateOf("") }
    // Panel v3.8.0 fields; empty leaves each client's value as it is.
    var hwid by remember { mutableStateOf("") }
    var adTag by remember { mutableStateOf("") }
    val adTagValid = isValidBulkAdTag(adTag.trim())
    val nothingSet = (days.toIntOrNull() ?: 0) == 0 && (gb.toDoubleOrNull() ?: 0.0) == 0.0 &&
        flow.isEmpty() && hwid.isEmpty() && adTag.isBlank()
    // API flow value → display label (matches the panel's bulk Adjust flow set).
    val flowLabels = linkedMapOf(
        "" to tr("No change"),
        "none" to tr("Clear flow"),
        "xtls-rprx-vision" to "xtls-rprx-vision",
        "xtls-rprx-vision-udp443" to "xtls-rprx-vision-udp443",
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${tr("Adjust")} ($count)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = days,
                    onValueChange = { days = it.filter { c -> c.isDigit() || c == '-' } },
                    label = { Text(tr("Add days (+/-)")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = gb,
                    onValueChange = { gb = it.filter { c -> c.isDigit() || c == '-' || c == '.' } },
                    label = { Text(tr("Add traffic (GB, +/-)")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                LabeledDropdown(tr("Set flow"), flowLabels[flow] ?: "", flowLabels.values.toList()) { sel ->
                    flow = flowLabels.entries.first { it.value == sel }.key
                }
                if (panel380) {
                    OutlinedTextField(
                        value = hwid,
                        onValueChange = { hwid = it.filter(Char::isDigit).take(4) },
                        label = { Text(tr("Device limit (0 = unlimited)")) },
                        supportingText = { Text(tr("Empty keeps each client's limit. Lowering it removes the extra registered devices.")) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = adTag,
                        onValueChange = { adTag = it.filter { c -> c.isLetterOrDigit() }.take(32) },
                        label = { Text(tr("MTProto ad tag")) },
                        supportingText = { Text(tr("32 hex characters to set, none to clear, empty to keep. MTProto inbounds only.")) },
                        isError = !adTagValid,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val addDays = days.toIntOrNull() ?: 0
                    val addBytes = ((gb.toDoubleOrNull() ?: 0.0) * 1024.0 * 1024.0 * 1024.0).toLong()
                    onApply(addDays, addBytes, flow, hwid.toIntOrNull(), adTag.trim())
                },
                enabled = !nothingSet && adTagValid,
            ) { Text(tr("Apply")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } },
    )
}
