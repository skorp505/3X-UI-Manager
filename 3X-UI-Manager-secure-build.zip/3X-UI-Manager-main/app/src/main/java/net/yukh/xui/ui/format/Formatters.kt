package net.yukh.xui.ui.format

import androidx.compose.runtime.compositionLocalOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ln
import kotlin.math.pow
import net.yukh.xui.i18n.LANG_EN
import net.yukh.xui.i18n.LANG_RU
import net.yukh.xui.i18n.LANG_ZH
import net.yukh.xui.i18n.tr

private val units = arrayOf("B", "KB", "MB", "GB", "TB", "PB")
private val bitUnits = arrayOf("bit/s", "Kbit/s", "Mbit/s", "Gbit/s", "Tbit/s")

/** Whether live speeds render in bits/s. Provided at the root from user prefs. */
val LocalSpeedInBits = compositionLocalOf { false }

/** Format a bytes/second rate. bytes → "12.0 KB/s" (1024-based, matching
 *  [formatBytes]); bits → "96.0 Kbit/s" (×8, 1000-based, network convention). */
fun formatSpeed(bytesPerSec: Long, bits: Boolean): String {
    if (!bits) return "${bytesPerSec.formatBytes()}/s"
    val v = (if (bytesPerSec < 0) 0 else bytesPerSec) * 8.0
    if (v == 0.0) return "0 bit/s"
    val exp = (ln(v) / ln(1000.0)).toInt().coerceIn(0, bitUnits.size - 1)
    return "%.1f %s".format(Locale.US, v / 1000.0.pow(exp.toDouble()), bitUnits[exp])
}

/** Pretty-print a byte count as e.g. "1.4 GB". 0 → "0 B"; negative → absolute. */
fun Long.formatBytes(): String {
    val abs = if (this < 0) -this else this
    if (abs == 0L) return "0 B"
    val exp = (ln(abs.toDouble()) / ln(1024.0)).toInt().coerceIn(0, units.size - 1)
    val value = abs / 1024.0.pow(exp.toDouble())
    return "%.1f %s".format(Locale.US, value, units[exp])
}

/** Format an inbound/client expiry timestamp (Unix ms). 0 → "Never". */
fun Long.formatExpiry(lang: String = LANG_EN): String {
    if (this == 0L) return tr(lang, "Never")
    val now = System.currentTimeMillis()
    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(this))
    return if (this < now) tr(lang, "Expired") + " " + date else date
}

/** Calendar date and time of day for an expiry timestamp (Unix ms), in the
 *  phone's own time zone. 0 → "Never". The panel stores expiry to the minute,
 *  so a date alone would hide half of what was set. */
fun Long.formatDateTime(lang: String = LANG_EN): String =
    if (this == 0L) tr(lang, "Never")
    else SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(this))

/** The phone's UTC offset at that instant, e.g. "UTC+03:00" — the clock the
 *  expiry above is expressed in, so nobody has to guess whose it is. */
fun Long.localZoneLabel(): String {
    val offset = TimeZone.getDefault().getOffset(if (this > 0) this else System.currentTimeMillis())
    val sign = if (offset < 0) "-" else "+"
    val minutes = kotlin.math.abs(offset) / 60_000
    return "UTC%s%02d:%02d".format(sign, minutes / 60, minutes % 60)
}

/** The same instant in another time zone, or null when the id is not a real
 *  zone — the panel's `timeLocation` defaults to "Local", which says nothing an
 *  outside caller can resolve. */
fun Long.formatDateTimeInZone(zoneId: String): String? {
    if (this <= 0L || zoneId.isBlank() || zoneId.equals("Local", ignoreCase = true)) return null
    val zone = TimeZone.getTimeZone(zoneId)
    if (zone.id != zoneId) return null
    return SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = zone }.format(Date(this))
}

/** Plain calendar date for an expiry timestamp (Unix ms). 0 → "Never". */
fun Long.formatDate(lang: String = LANG_EN): String =
    if (this == 0L) tr(lang, "Never") else SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(this))

/** Short day.month for a period start, e.g. "01.06" (Unix ms). 0 → "". */
fun Long.formatDayMonth(): String =
    if (this <= 0L) "" else SimpleDateFormat("dd.MM", Locale.US).format(Date(this))

/** Days remaining until expiry (Unix ms). 0 → "Never"; already past → "Expired";
 *  otherwise the whole-day count with a short unit ("12 d" / "12 дн."). */
fun Long.formatExpiryDays(lang: String = LANG_EN): String {
    if (this == 0L) return tr(lang, "Never")
    val days = (this - System.currentTimeMillis()) / 86_400_000L
    if (days < 0) return tr(lang, "Expired")
    val unit = when (lang) {
        LANG_RU -> "дн."
        LANG_ZH -> "天"
        else -> "d"
    }
    return "$days $unit"
}

/** Format a relative timestamp ("12s ago", "5m ago"). 0 → "—". */
fun Long.formatLastOnline(lang: String = LANG_EN): String {
    if (this <= 0L) return "—"
    val elapsedMs = System.currentTimeMillis() - this
    if (elapsedMs < 0) return tr(lang, "now")
    val seconds = elapsedMs / 1_000
    return when {
        seconds < 60 -> "${seconds}${tr(lang, "s ago")}"
        seconds < 3_600 -> "${seconds / 60}${tr(lang, "m ago")}"
        seconds < 86_400 -> "${seconds / 3_600}${tr(lang, "h ago")}"
        else -> "${seconds / 86_400}${tr(lang, "d ago")}"
    }
}

/** "5.5%" rounded to one decimal. */
fun Double.formatPercent(): String = "%.1f%%".format(Locale.US, this)

/** Format an uptime given in seconds as "12d 3h 5m". */
fun Long.formatUptime(): String {
    if (this <= 0) return "—"
    val days = this / 86_400
    val hours = (this % 86_400) / 3_600
    val minutes = (this % 3_600) / 60
    return buildList {
        if (days > 0) add("${days}d")
        if (hours > 0) add("${hours}h")
        if (minutes > 0 || isEmpty()) add("${minutes}m")
    }.joinToString(" ")
}
