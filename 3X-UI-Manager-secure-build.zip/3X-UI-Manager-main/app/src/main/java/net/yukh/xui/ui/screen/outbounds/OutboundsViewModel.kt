package net.yukh.xui.ui.screen.outbounds

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import net.yukh.xui.data.api.dto.TestOutboundResult
import net.yukh.xui.data.api.dto.defaultOutbound
import net.yukh.xui.data.api.dto.outboundTag
import net.yukh.xui.data.json.array
import net.yukh.xui.data.json.asObject
import net.yukh.xui.data.json.putArray
import net.yukh.xui.data.repo.PanelRepository
import net.yukh.xui.data.repo.isUnsupportedByPanel
import net.yukh.xui.data.repo.panelVersionAtLeast
import net.yukh.xui.ui.screen.xrayedit.xraySaveMessage

private val prettyJson = Json { prettyPrint = true; isLenient = true }

/** The outbound currently open in the editor. [index] = -1 for a new one. */
data class EditingOutbound(val index: Int, val isNew: Boolean, val draft: JsonObject)

data class OutboundsUiState(
    val loading: Boolean = true,
    val available: Boolean = false,
    /** The panel is older than this feature (its endpoint 404s). */
    val unsupported: Boolean = false,
    val outbounds: List<JsonObject> = emptyList(),
    /** Read-only outbounds the panel injects from outbound subscriptions —
     *  they aren't part of the editable template, so they can't be saved back. */
    val subscriptionOutbounds: List<JsonObject> = emptyList(),
    val dirty: Boolean = false,
    val saving: Boolean = false,
    val error: String? = null,
    val savedMessage: String? = null,
    val editing: EditingOutbound? = null,
    val editorError: String? = null,
    // Outbound connectivity test (panel 3.5.0): mode + per-index results/in-flight.
    val testMode: String = "tcp",
    val testResults: Map<Int, TestOutboundResult> = emptyMap(),
    val testing: Set<Int> = emptySet(),
    // Same, for the subscription-injected outbounds (kept apart so the indices
    // of the editable list stay meaningful).
    val subTestResults: Map<Int, TestOutboundResult> = emptyMap(),
    val subTesting: Set<Int> = emptySet(),
    /** Panel v3.8.0+: AmneziaWG can be chosen as an outbound protocol. */
    val panel380: Boolean = false,
    val panel3100: Boolean = false,
)

@HiltViewModel
class OutboundsViewModel @Inject constructor(
    private val repo: PanelRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(OutboundsUiState())
    val state: StateFlow<OutboundsUiState> = _state.asStateFlow()

    // The full config, kept verbatim so siblings (routing/balancers/dns/…) survive.
    private var configObj: JsonObject = JsonObject(emptyMap())
    private var testUrl: String = "https://www.google.com/generate_204"

    fun load() {
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val panel380 = repo.isPanel380()
            val panel3100 = panelVersionAtLeast(repo.panelVersion(), 3, 10, 0)
            _state.update { it.copy(panel380 = panel380, panel3100 = panel3100) }
            repo.getXraySetting()
                .onSuccess { env ->
                    configObj = env.xraySetting.asObject()
                    testUrl = env.outboundTestUrl
                    val list = configObj.array("outbounds").map { it.asObject() }
                    _state.update {
                        it.copy(
                            loading = false, available = true, outbounds = list, dirty = false, error = null,
                            subscriptionOutbounds = env.subscriptionOutbounds,
                            testResults = emptyMap(), testing = emptySet(),
                        )
                    }
                }
                .onFailure { e ->
                    _state.update {
                        it.copy(loading = false, available = false, unsupported = e.isUnsupportedByPanel(), error = e.message ?: "Xray config unavailable")
                    }
                }
        }
    }

    // ---- outbound connectivity test (panel 3.5.0) -------------------------

    fun setTestMode(mode: String) = _state.update { it.copy(testMode = mode) }

    /** Test an outbound injected by a subscription. They can't be edited (the
     *  panel regenerates them on each refresh), but they are testable and
     *  routable just like the manual ones. */
    fun testSubscriptionOutbound(index: Int) {
        val ob = _state.value.subscriptionOutbounds.getOrNull(index) ?: return
        val mode = _state.value.testMode
        _state.update { it.copy(subTesting = it.subTesting + index) }
        viewModelScope.launch {
            repo.testOutbound(ob, mode)
                .onSuccess { r ->
                    _state.update { it.copy(subTestResults = it.subTestResults + (index to r), subTesting = it.subTesting - index) }
                }
                .onFailure { e ->
                    _state.update {
                        it.copy(
                            subTestResults = it.subTestResults + (index to TestOutboundResult(success = false, error = e.message ?: "test failed")),
                            subTesting = it.subTesting - index,
                        )
                    }
                }
        }
    }

    fun testOutbound(index: Int) {
        val ob = _state.value.outbounds.getOrNull(index) ?: return
        val mode = _state.value.testMode
        _state.update { it.copy(testing = it.testing + index) }
        viewModelScope.launch {
            repo.testOutbound(ob, mode)
                .onSuccess { r ->
                    _state.update { it.copy(testResults = it.testResults + (index to r), testing = it.testing - index) }
                }
                .onFailure { e ->
                    _state.update {
                        it.copy(
                            testResults = it.testResults + (index to TestOutboundResult(success = false, error = e.message ?: "test failed")),
                            testing = it.testing - index,
                        )
                    }
                }
        }
    }

    // ---- list actions (local until save) ----------------------------------

    fun openNew() = _state.update {
        it.copy(editing = EditingOutbound(-1, isNew = true, draft = defaultOutbound("vless", "")), editorError = null)
    }

    /** Open the editor pre-filled with an outbound parsed from a share link. */
    fun openImported(draft: JsonObject) = _state.update {
        it.copy(editing = EditingOutbound(-1, isNew = true, draft = draft), editorError = null)
    }

    fun openEdit(index: Int) = _state.update {
        val ob = it.outbounds.getOrNull(index) ?: return@update it
        it.copy(editing = EditingOutbound(index, isNew = false, draft = ob), editorError = null)
    }

    fun closeEditor() = _state.update { it.copy(editing = null, editorError = null) }

    fun updateDraft(draft: JsonObject) = _state.update {
        it.copy(editing = it.editing?.copy(draft = draft), editorError = null)
    }

    /** Validate the draft, commit it to the list and save the config; keeps the editor open on error. */
    fun saveDraft() {
        val st = _state.value
        val ed = st.editing ?: return
        val tag = ed.draft.outboundTag().trim()
        if (tag.isBlank()) {
            _state.update { it.copy(editorError = "Tag is required") }
            return
        }
        val clash = st.outbounds.withIndex().any { (i, ob) -> i != ed.index && ob.outboundTag() == tag }
        if (clash) {
            _state.update { it.copy(editorError = "Tag already used by another outbound") }
            return
        }
        val list = st.outbounds.toMutableList()
        if (ed.isNew) list.add(ed.draft) else list[ed.index] = ed.draft
        _state.update { it.copy(outbounds = list, dirty = true, editing = null, editorError = null) }
        save()
    }

    fun deleteAt(index: Int) = _state.update {
        val list = it.outbounds.toMutableList()
        if (index in list.indices) list.removeAt(index)
        it.copy(outbounds = list, dirty = true, testResults = emptyMap())
    }

    /** Move the outbound at [index] by [delta] (-1 up / +1 down). Order = priority. */
    fun move(index: Int, delta: Int) = _state.update {
        val list = it.outbounds.toMutableList()
        val to = index + delta
        if (index in list.indices && to in list.indices) {
            val item = list.removeAt(index)
            list.add(to, item)
            it.copy(outbounds = list, dirty = true, testResults = emptyMap())
        } else it
    }

    /** Append imported outbounds to the list (kept verbatim; saved on Save). */
    fun appendOutbounds(items: List<JsonObject>) = _state.update {
        it.copy(outbounds = it.outbounds + items, dirty = true)
    }

    // ---- persistence -------------------------------------------------------

    fun save() {
        val st = _state.value
        if (st.saving) return
        val updated = configObj.putArray("outbounds", st.outbounds)
        val minified = prettyJson.encodeToString(JsonElement.serializer(), updated)
        _state.update { it.copy(saving = true, error = null) }
        viewModelScope.launch {
            repo.updateXraySetting(minified, testUrl.trim())
                .onSuccess {
                    val msg = repo.xraySaveMessage()
                    configObj = updated
                    _state.update {
                        it.copy(saving = false, dirty = false, savedMessage = msg)
                    }
                }
                .onFailure { e ->
                    _state.update { it.copy(saving = false, error = e.message ?: "Save failed") }
                }
        }
    }

    fun dismissSavedMessage() = _state.update { it.copy(savedMessage = null) }
    fun dismissError() = _state.update { it.copy(error = null) }
}
