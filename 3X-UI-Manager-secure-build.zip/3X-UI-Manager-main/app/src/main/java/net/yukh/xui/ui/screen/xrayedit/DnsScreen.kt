package net.yukh.xui.ui.screen.xrayedit

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import net.yukh.xui.data.json.array
import net.yukh.xui.data.json.asObject
import net.yukh.xui.data.json.bool
import net.yukh.xui.data.json.child
import net.yukh.xui.data.json.int
import net.yukh.xui.data.json.parseCsv
import net.yukh.xui.data.json.put
import net.yukh.xui.data.json.putArray
import net.yukh.xui.data.json.putBool
import net.yukh.xui.data.json.putInt
import net.yukh.xui.data.json.putString
import net.yukh.xui.data.json.putStrings
import net.yukh.xui.data.json.string
import net.yukh.xui.data.json.strings
import net.yukh.xui.i18n.LocalAppLanguage
import net.yukh.xui.i18n.tr
import net.yukh.xui.ui.components.PanelFeatureUnsupported
import net.yukh.xui.ui.components.ConfirmDialog
import net.yukh.xui.ui.components.ExportJsonDialog
import net.yukh.xui.ui.components.Field
import net.yukh.xui.ui.components.ImportJsonDialog
import net.yukh.xui.ui.components.LabeledDropdown
import net.yukh.xui.ui.components.SectionTitle
import net.yukh.xui.ui.components.SwitchRow

private val DNS_QUERY_STRATEGY = listOf("UseIP", "UseIPv4", "UseIPv6", "UseSystem")

/** Parse a DNS-servers import: a bare array, `{servers:[…]}`, or `{dns:{servers:[…]}}`. */
private fun parseServersImport(text: String): List<JsonElement>? {
    val el = try { Json.parseToJsonElement(text.trim()) } catch (e: Exception) { return null }
    val arr = when (el) {
        is JsonArray -> el
        is JsonObject -> (el["servers"] as? JsonArray)
            ?: ((el["dns"] as? JsonObject)?.get("servers") as? JsonArray)
        else -> null
    }
    return arr?.toList()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DnsScreen(onClose: () -> Unit, vm: DnsViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.load() }
    val lang = LocalAppLanguage.current
    LaunchedEffect(state.savedMessage) { state.savedMessage?.let { snackbar.showSnackbar(tr(lang, it)); vm.dismissSavedMessage() } }
    LaunchedEffect(state.error) { if (state.available) state.error?.let { snackbar.showSnackbar(it); vm.dismissError() } }

    val editing = state.editingServer
    if (editing != null) {
        // System Back leaves the editor; without this it closed the whole DNS screen.
        androidx.activity.compose.BackHandler(onBack = vm::closeServer)
        DnsServerEditor(
            draft = editing.draft,
            isNew = editing.isNew,
            onChange = vm::updateServerDraft,
            onCancel = vm::closeServer,
            onDone = {
                val cfg = state.config
                val dns = cfg.child("dns")
                val arr = dns.array("servers").toMutableList()
                val el = serverToElement(editing.draft)
                if (editing.isNew) arr.add(el) else arr[editing.index] = el
                vm.update(cfg.put("dns", dns.putArray("servers", arr)))
                vm.closeServer()
                vm.save()
            },
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(tr("DNS")) },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr("Close")) } },
                actions = {
                    if (state.available) TextButton(onClick = vm::save, enabled = state.dirty && !state.saving) {
                        if (state.saving) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) else Text(tr("Save"))
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) { Snackbar { Text(it.visuals.message) } } },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                state.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                state.unsupported -> PanelFeatureUnsupported(tr("DNS"))

                !state.available -> SessionGate()
                else -> DnsBody(state.config, vm)
            }
        }
    }
}

@Composable
private fun DnsBody(cfg: JsonObject, vm: DnsViewModel) {
    val dnsEnabled = cfg["dns"] is JsonObject
    val dns = cfg.child("dns")
    var pendingDelete by remember { androidx.compose.runtime.mutableStateOf<Int?>(null) }
    var showExport by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SwitchRow(tr("Enable DNS"), dnsEnabled) { on ->
            if (on) {
                val def = JsonObject(emptyMap()).putString("tag", "dns_inbound").putString("queryStrategy", "UseIP")
                    .putArray("servers", emptyList())
                vm.update(cfg.put("dns", def))
            } else {
                vm.update(cfg.put("dns", null).put("fakedns", null))
            }
        }

        if (dnsEnabled) {
            fun setDns(d: JsonObject) = vm.update(cfg.put("dns", d))
            Field(tr("DNS tag"), dns.string("tag")) { setDns(dns.putString("tag", it)) }
            Field(tr("Client IP"), dns.string("clientIp")) { setDns(dns.putString("clientIp", it)) }
            LabeledDropdown(tr("Query strategy"), dns.string("queryStrategy").ifBlank { "UseIP" }, DNS_QUERY_STRATEGY) {
                setDns(dns.putString("queryStrategy", it))
            }
            // Panel 3.10: a blank script must be removed — Xray refuses to start on an empty path.
            Field(tr("Lua Script"), dns.string("script")) { setDns(if (it.isBlank()) dns.put("script", null) else dns.putString("script", it)) }
            HelpText(tr("Path to a .lua file defining HandleDNSQuery, absolute or relative to the Xray bin folder. The script then answers every query and reaches the servers only through its own code. Xray will not start if the file is missing or invalid."))
            SwitchRow(tr("Disable cache"), dns.bool("disableCache")) { setDns(dns.putBool("disableCache", it)) }
            SwitchRow(tr("Disable fallback"), dns.bool("disableFallback")) { setDns(dns.putBool("disableFallback", it)) }
            SwitchRow(tr("Disable fallback if match"), dns.bool("disableFallbackIfMatch")) { setDns(dns.putBool("disableFallbackIfMatch", it)) }
            SwitchRow(tr("Parallel query"), dns.bool("enableParallelQuery")) { setDns(dns.putBool("enableParallelQuery", it)) }
            SwitchRow(tr("Use system hosts"), dns.bool("useSystemHosts")) { setDns(dns.putBool("useSystemHosts", it)) }

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(tr("DNS servers"))
                Box(modifier = Modifier.weight(1f))
                FilledTonalIconButton(onClick = { showImport = true }) {
                    Icon(Icons.Outlined.FileUpload, contentDescription = tr("Import"))
                }
                FilledTonalIconButton(onClick = { showExport = true }, enabled = dns.array("servers").isNotEmpty()) {
                    Icon(Icons.Outlined.FileDownload, contentDescription = tr("Export"))
                }
            }
            val servers = dns.array("servers")
            servers.forEachIndexed { i, el ->
                val o = serverToObject(el)
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { vm.openServer(i, o, isNew = false) },
                ) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(o.string("address").ifBlank { "(no address)" }, style = MaterialTheme.typography.titleSmall)
                            val sub = o.strings("domains").joinToString(", ").ifBlank { o.strings(o.expectedIpsKey()).joinToString(", ") }
                            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { pendingDelete = i }) { Icon(Icons.Outlined.Delete, contentDescription = tr("Delete")) }
                    }
                }
            }
            OutlinedButton(onClick = { vm.openServer(-1, JsonObject(emptyMap()).putString("address", ""), isNew = true) }) {
                Icon(Icons.Filled.Add, contentDescription = null); Text("  " + tr("Add DNS server"))
            }

            SectionTitle(tr("FakeDNS"))
            val fake = (cfg["fakedns"] as? JsonArray) ?: JsonArray(emptyList())
            fun setFake(items: List<kotlinx.serialization.json.JsonElement>) =
                vm.update(if (items.isEmpty()) cfg.put("fakedns", null) else cfg.putArray("fakedns", items))
            fake.forEachIndexed { i, el ->
                val o = el.asObject()
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        Field(tr("IP pool"), o.string("ipPool")) {
                            val arr = fake.toMutableList(); arr[i] = o.putString("ipPool", it); setFake(arr)
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        Field(tr("Pool size"), o.int("poolSize")?.toString() ?: "", numeric = true) {
                            val arr = fake.toMutableList(); arr[i] = o.putInt("poolSize", it.toIntOrNull() ?: 65535); setFake(arr)
                        }
                    }
                    IconButton(onClick = { val arr = fake.toMutableList(); arr.removeAt(i); setFake(arr) }) {
                        Icon(Icons.Outlined.Delete, contentDescription = tr("Delete"))
                    }
                }
            }
            OutlinedButton(onClick = {
                val def = JsonObject(emptyMap()).putString("ipPool", "198.18.0.0/15").putInt("poolSize", 65535)
                setFake(fake.toMutableList().apply { add(def) })
            }) { Icon(Icons.Filled.Add, contentDescription = null); Text("  " + tr("Add FakeDNS")) }
        }
    }

    pendingDelete?.let { idx ->
        ConfirmDialog(
            title = tr("Delete DNS server?"),
            text = serverToObject(cfg.child("dns").array("servers").getOrElse(idx) { JsonPrimitive("") }).string("address"),
            confirmLabel = tr("Delete"),
            destructive = true,
            onConfirm = {
                pendingDelete = null
                val dns = cfg.child("dns")
                val arr = dns.array("servers").toMutableList(); if (idx in arr.indices) arr.removeAt(idx)
                vm.update(cfg.put("dns", dns.putArray("servers", arr)))
            },
            onDismiss = { pendingDelete = null },
        )
    }

    if (showExport) {
        ExportJsonDialog(
            title = tr("Export DNS servers"),
            json = xrayPrettyJson.encodeToString(JsonElement.serializer(), dns.array("servers")),
            onDismiss = { showExport = false },
        )
    }
    if (showImport) {
        val invalidMsg = tr("Invalid JSON")
        val importedLabel = tr("Imported")
        ImportJsonDialog(
            title = tr("Import DNS servers"),
            onImport = { txt ->
                val parsed = parseServersImport(txt) ?: return@ImportJsonDialog invalidMsg
                vm.update(cfg.put("dns", dns.putArray("servers", dns.array("servers").toList() + parsed)))
                vm.info("$importedLabel: ${parsed.size}")
                null
            },
            onDismiss = { showImport = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DnsServerEditor(
    draft: JsonObject,
    isNew: Boolean,
    onChange: (JsonObject) -> Unit,
    onCancel: () -> Unit,
    onDone: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isNew) tr("New DNS server") else tr("Edit DNS server")) },
                navigationIcon = { IconButton(onClick = onCancel) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr("Close")) } },
                actions = { TextButton(onClick = onDone) { Text(tr("Save")) } },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Field(tr("Address"), draft.string("address")) { onChange(draft.putString("address", it)) }
            Field(tr("Port"), draft.int("port")?.toString() ?: "", numeric = true) { onChange(draft.putInt("port", it.toIntOrNull() ?: 53)) }
            Field(tr("ID"), draft.string("id")) { onChange(if (it.isBlank()) draft.put("id", null) else draft.putString("id", it)) }
            HelpText(tr("The name a Lua DNS script uses to pick this server"))
            LabeledDropdown(tr("Query strategy"), draft.string("queryStrategy").ifBlank { "UseIP" }, DNS_QUERY_STRATEGY) {
                onChange(draft.putString("queryStrategy", it))
            }
            Field(tr("Domains (comma-separated)"), draft.strings("domains").joinToString(", ")) { onChange(draft.putStrings("domains", parseCsv(it))) }
            val ipsKey = draft.expectedIpsKey()
            Field(tr("Expected IPs (comma-separated)"), draft.strings(ipsKey).joinToString(", ")) { onChange(draft.putStrings(ipsKey, parseCsv(it))) }
            Field(tr("Unexpected IPs (comma-separated)"), draft.strings("unexpectedIPs").joinToString(", ")) { onChange(draft.putStrings("unexpectedIPs", parseCsv(it))) }
            SwitchRow(tr("Skip fallback"), draft.bool("skipFallback")) { onChange(draft.putBool("skipFallback", it)) }
            SwitchRow(tr("Disable cache"), draft.bool("disableCache")) { onChange(draft.putBool("disableCache", it)) }
            SwitchRow(tr("Final query"), draft.bool("finalQuery")) { onChange(draft.putBool("finalQuery", it)) }
        }
    }
}

@Composable
private fun HelpText(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
