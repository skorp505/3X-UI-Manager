package net.yukh.xui.ui.screen.main

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.AllInbox
import androidx.compose.material.icons.outlined.AltRoute
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Balance
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch
import net.yukh.xui.data.repo.PanelRepository
import net.yukh.xui.i18n.tr
import net.yukh.xui.ui.navigation.MainTabs
import net.yukh.xui.ui.screen.backup.BackupScreen
import net.yukh.xui.ui.screen.clients.ClientEditorScreen
import net.yukh.xui.ui.screen.clients.ClientsScreen
import net.yukh.xui.ui.screen.clients.ClientsViewModel
import net.yukh.xui.ui.screen.connect.ConnectScreen
import net.yukh.xui.ui.screen.connect.ConnectViewModel
import net.yukh.xui.ui.screen.dashboard.DashboardScreen
import net.yukh.xui.ui.screen.groups.GroupsScreen
import net.yukh.xui.ui.screen.inbounds.InboundEditorScreen
import net.yukh.xui.ui.screen.inbounds.InboundsScreen
import net.yukh.xui.ui.screen.inbounds.InboundsViewModel
import net.yukh.xui.ui.screen.nodes.NodeEditorScreen
import net.yukh.xui.ui.screen.nodes.NodeMtlsScreen
import net.yukh.xui.ui.screen.nodes.NodesScreen
import net.yukh.xui.ui.screen.nodes.NodesViewModel
import net.yukh.xui.ui.screen.outbounds.OutboundsScreen
import net.yukh.xui.ui.screen.paneladmin.PanelAdminScreen
import net.yukh.xui.ui.screen.profiles.ProfileSwitcherSheet
import net.yukh.xui.ui.screen.settings.AboutScreen
import net.yukh.xui.ui.screen.settings.SettingsScreen
import net.yukh.xui.ui.screen.xray.XrayConfigScreen
import net.yukh.xui.ui.screen.xrayedit.BalancersScreen
import net.yukh.xui.ui.screen.xrayedit.DnsScreen
import net.yukh.xui.ui.screen.xrayedit.GeneralScreen
import net.yukh.xui.ui.screen.xrayedit.GeodataScreen
import net.yukh.xui.ui.screen.xrayedit.RoutingScreen
import net.yukh.xui.update.ChangelogNotes
import net.yukh.xui.update.UpdateDialogHost
import net.yukh.xui.update.UpdateViewModel

@HiltViewModel
class MainViewModel @Inject constructor(
    private val repo: PanelRepository,
) : ViewModel() {
    val profiles = repo.profiles
    val activeProfileId = repo.activeProfileId
    fun switchProfile(id: String) { viewModelScope.launch { repo.switchProfile(id) } }
    fun deleteProfile(id: String) = repo.deleteProfile(id)
}

private data class BottomTabSpec(
    val route: String,
    val label: String,
    val icon: ImageVector,
)

private val tabs = listOf(
    BottomTabSpec(MainTabs.Dashboard, "Dashboard", Icons.Outlined.Dashboard),
    BottomTabSpec(MainTabs.Inbounds, "Inbounds", Icons.Outlined.AllInbox),
    BottomTabSpec(MainTabs.Clients, "Clients", Icons.Outlined.People),
    BottomTabSpec(MainTabs.Nodes, "Nodes", Icons.Outlined.Hub),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    vm: MainViewModel = hiltViewModel(),
) {
    val innerNav = rememberNavController()
    val backEntry by innerNav.currentBackStackEntryAsState()
    val currentRoute = backEntry?.destination?.route ?: MainTabs.Dashboard
    val currentTab = tabs.firstOrNull { it.route == currentRoute } ?: tabs.first()
    var menuOpen by remember { mutableStateOf(false) }
    // Overlay visibility uses rememberSaveable so it survives activity recreation
    // (e.g. backgrounding the app to copy a panel URL) — you return to the same
    // overlay instead of being dropped back to the Dashboard.
    var showXrayConfig by rememberSaveable { mutableStateOf(false) }
    var showOutbounds by rememberSaveable { mutableStateOf(false) }
    var showRouting by rememberSaveable { mutableStateOf(false) }
    var showBalancers by rememberSaveable { mutableStateOf(false) }
    var showDns by rememberSaveable { mutableStateOf(false) }
    var showGeneral by rememberSaveable { mutableStateOf(false) }
    var showGeodata by rememberSaveable { mutableStateOf(false) }
    var showBackup by rememberSaveable { mutableStateOf(false) }
    var showPanelAdmin by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showAbout by rememberSaveable { mutableStateOf(false) }
    var showProfiles by rememberSaveable { mutableStateOf(false) }
    var showAddPanel by rememberSaveable { mutableStateOf(false) }
    var showGroups by rememberSaveable { mutableStateOf(false) }

    // Shared Connect VM for the "add panel" overlay; cleared when opening so the
    // form starts blank (vs. the default which pre-fills the active profile).
    val connectVm: ConnectViewModel = hiltViewModel()

    // The editor-bearing VMs are created here and shared with the tab screens, so
    // their full-screen editors can be rendered as overlays in THIS (activity)
    // window — Compose Dialog windows don't reliably get system-bar / IME insets,
    // which is why editor action buttons used to hide under the nav bar/keyboard.
    val inboundsVm: InboundsViewModel = hiltViewModel()
    val clientsVm: ClientsViewModel = hiltViewModel()
    val nodesVm: NodesViewModel = hiltViewModel()
    val inboundsState by inboundsVm.state.collectAsStateWithLifecycle()
    val clientsState by clientsVm.state.collectAsStateWithLifecycle()
    val nodesState by nodesVm.state.collectAsStateWithLifecycle()
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val activeProfileId by vm.activeProfileId.collectAsStateWithLifecycle()
    val activeLabel = profiles.firstOrNull { it.id == activeProfileId }?.label

    // Self-update: check GitLab releases once on launch (silent unless newer).
    val updateVm: UpdateViewModel = hiltViewModel()
    LaunchedEffect(Unit) { updateVm.checkOnStart() }

    Box(modifier = Modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(tr(currentTab.label), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        // Show which panel is active (with multi-profile) so it's
                        // always clear what you're connected to; tap ⇄ to switch.
                        activeLabel?.let {
                            Text(
                                it,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showProfiles = true }) {
                        Icon(Icons.Outlined.SwapHoriz, contentDescription = tr("Switch panel"))
                    }
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Outlined.MoreVert, contentDescription = tr("Menu"))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(tr("Outbounds")) },
                            leadingIcon = { Icon(Icons.Outlined.SwapVert, contentDescription = null) },
                            onClick = { menuOpen = false; showOutbounds = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Routing")) },
                            leadingIcon = { Icon(Icons.Outlined.AltRoute, contentDescription = null) },
                            onClick = { menuOpen = false; showRouting = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Balancers")) },
                            leadingIcon = { Icon(Icons.Outlined.Balance, contentDescription = null) },
                            onClick = { menuOpen = false; showBalancers = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("DNS")) },
                            leadingIcon = { Icon(Icons.Outlined.Dns, contentDescription = null) },
                            onClick = { menuOpen = false; showDns = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("General / Logs")) },
                            leadingIcon = { Icon(Icons.Outlined.Article, contentDescription = null) },
                            onClick = { menuOpen = false; showGeneral = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Geodata auto-update")) },
                            leadingIcon = { Icon(Icons.Outlined.Public, contentDescription = null) },
                            onClick = { menuOpen = false; showGeodata = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Xray config")) },
                            leadingIcon = { Icon(Icons.Outlined.Tune, contentDescription = null) },
                            onClick = { menuOpen = false; showXrayConfig = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Backup / restore")) },
                            leadingIcon = { Icon(Icons.Outlined.Backup, contentDescription = null) },
                            onClick = { menuOpen = false; showBackup = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Panel admin")) },
                            leadingIcon = { Icon(Icons.Outlined.AdminPanelSettings, contentDescription = null) },
                            onClick = { menuOpen = false; showPanelAdmin = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Node mTLS")) },
                            leadingIcon = { Icon(Icons.Outlined.Security, contentDescription = null) },
                            onClick = { menuOpen = false; nodesVm.openMtls() },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("Settings")) },
                            leadingIcon = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                            onClick = { menuOpen = false; showSettings = true },
                        )
                        DropdownMenuItem(
                            text = { Text(tr("About")) },
                            leadingIcon = { Icon(Icons.Outlined.Info, contentDescription = null) },
                            onClick = { menuOpen = false; showAbout = true },
                        )
                    }
                },
            )
        },
        bottomBar = {
            // Icons only, with a single centred caption for the selected tab.
            // A per-item label wrapped onto two lines (and pushed the row out of
            // shape) on devices with an enlarged system font.
            Surface(tonalElevation = 3.dp) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(vertical = 6.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        tabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            IconButton(
                                onClick = {
                                    innerNav.navigate(tab.route) {
                                        popUpTo(innerNav.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                            ) {
                                Icon(
                                    tab.icon,
                                    contentDescription = tr(tab.label),
                                    tint = if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    Text(
                            tr(currentTab.label),
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = innerNav,
            startDestination = MainTabs.Dashboard,
            modifier = Modifier.padding(padding),
        ) {
            composable(MainTabs.Dashboard) {
                val latestApp by updateVm.latestAvailable.collectAsStateWithLifecycle()
                DashboardScreen(
                    appUpdateVersion = latestApp?.version?.let(ChangelogNotes::displayVersion),
                    onAppUpdate = updateVm::reshow,
                )
            }
            composable(MainTabs.Inbounds) { InboundsScreen(vm = inboundsVm) }
            composable(MainTabs.Clients) { ClientsScreen(onOpenGroups = { showGroups = true }, vm = clientsVm) }
            composable(MainTabs.Nodes) { NodesScreen(vm = nodesVm) }
        }
    }

    // ---- Full-screen overlays (rendered in the activity window so system-bar
    // and keyboard insets work; each is opaque and covers the bottom nav) ----

    inboundsState.editor?.let { editor ->
        BackHandler(onBack = inboundsVm::closeEditor)
        InboundEditorScreen(state = editor, vm = inboundsVm)
    }

    if (showGroups) {
        // Group changes land on clients too, so the list behind refreshes right away.
        val closeGroups = { showGroups = false; clientsVm.load(force = true) }
        BackHandler(onBack = closeGroups)
        // Drawn before the client editor, so an editor opened from a member's sheet sits on top.
        GroupsScreen(onClose = closeGroups, onOpenClient = clientsVm::openShareSheet)
    }

    clientsState.editor?.let { editor ->
        BackHandler(onBack = clientsVm::closeEditor)
        ClientEditorScreen(
            state = editor,
            onEmail = clientsVm::setEditorEmail,
            onEnable = clientsVm::setEditorEnable,
            onLimitIp = clientsVm::setEditorLimitIp,
            onTotalGb = clientsVm::setEditorTotalGb,
            onReset = clientsVm::setEditorReset,
            onResetDay = clientsVm::setEditorResetDay,
            onResetMax = clientsVm::setEditorResetMax,
            onTrafficReset = clientsVm::setEditorTrafficReset,
            onTrafficResetDay = clientsVm::setEditorTrafficResetDay,
            onLimitHwid = clientsVm::setEditorLimitHwid,
            onForwardedPorts = clientsVm::setEditorForwardedPorts,
            onShowDevices = { editor.source?.email?.let(clientsVm::openHwids) },
            onTgId = clientsVm::setEditorTgId,
            onGroup = clientsVm::setEditorGroup,
            onComment = clientsVm::setEditorComment,
            onAdTag = clientsVm::setEditorAdTag,
            onRegenerateSecret = clientsVm::regenerateSecret,
            onAllowedIps = clientsVm::setEditorAllowedIps,
            onKeepAlive = clientsVm::setEditorKeepAlive,
            onExpiry = clientsVm::setEditorExpiry,
            onToggleInbound = clientsVm::toggleEditorInbound,
            onSave = clientsVm::saveEditor,
            onClose = clientsVm::closeEditor,
        )
    }

    nodesState.editor?.let { editor ->
        BackHandler(onBack = nodesVm::closeEditor)
        NodeEditorScreen(
            state = editor,
            onName = nodesVm::setName,
            onRemark = nodesVm::setRemark,
            onScheme = nodesVm::setScheme,
            onAddress = nodesVm::setAddress,
            onPort = nodesVm::setPort,
            onBasePath = nodesVm::setBasePath,
            onApiToken = nodesVm::setApiToken,
            onEnable = nodesVm::setEnable,
            onAllowPrivate = nodesVm::setAllowPrivate,
            onTlsVerifyMode = nodesVm::setTlsVerifyMode,
            onPinnedCert = nodesVm::setPinnedCert,
            onOutboundTag = nodesVm::setOutboundTag,
            onSave = nodesVm::saveEditor,
            onDelete = { nodesVm.deleteNode(editor.id) },
            onClose = nodesVm::closeEditor,
        )
    }

    if (nodesState.mtlsOpen) {
        BackHandler(onBack = nodesVm::closeMtls)
        NodeMtlsScreen(
            panelCa = nodesState.mtlsCa,
            busy = nodesState.mtlsBusy,
            onSaveTrustCa = nodesVm::saveMtlsTrustCa,
            onReloadCredential = nodesVm::reloadMtlsCredential,
            onClose = nodesVm::closeMtls,
        )
    }

    if (showXrayConfig) {
        BackHandler(onBack = { showXrayConfig = false })
        XrayConfigScreen(onClose = { showXrayConfig = false })
    }

    if (showOutbounds) {
        BackHandler(onBack = { showOutbounds = false })
        OutboundsScreen(onClose = { showOutbounds = false })
    }

    if (showRouting) {
        BackHandler(onBack = { showRouting = false })
        RoutingScreen(onClose = { showRouting = false })
    }

    if (showBalancers) {
        BackHandler(onBack = { showBalancers = false })
        BalancersScreen(onClose = { showBalancers = false })
    }

    if (showDns) {
        BackHandler(onBack = { showDns = false })
        DnsScreen(onClose = { showDns = false })
    }

    if (showGeneral) {
        BackHandler(onBack = { showGeneral = false })
        GeneralScreen(onClose = { showGeneral = false })
    }

    if (showGeodata) {
        BackHandler(onBack = { showGeodata = false })
        GeodataScreen(onClose = { showGeodata = false })
    }

    if (showBackup) {
        BackHandler(onBack = { showBackup = false })
        BackupScreen(onClose = { showBackup = false })
    }

    if (showPanelAdmin) {
        BackHandler(onBack = { showPanelAdmin = false })
        PanelAdminScreen(onClose = { showPanelAdmin = false })
    }

    if (showSettings) {
        BackHandler(onBack = { showSettings = false })
        SettingsScreen(onClose = { showSettings = false }, onCheckUpdates = { updateVm.checkNow() })
    }

    if (showAbout) {
        BackHandler(onBack = { showAbout = false })
        AboutScreen(onClose = { showAbout = false })
    }

    UpdateDialogHost(updateVm)

    if (showProfiles) {
        ProfileSwitcherSheet(
            profiles = profiles,
            activeId = activeProfileId,
            onSwitch = vm::switchProfile,
            onAdd = { showProfiles = false; connectVm.clearForm(); showAddPanel = true },
            onEdit = { showProfiles = false; connectVm.startEdit(it); showAddPanel = true },
            onDelete = vm::deleteProfile,
            onDismiss = { showProfiles = false },
        )
    }

    if (showAddPanel) {
        BackHandler(onBack = { showAddPanel = false })
        ConnectScreen(
            onConnected = { showAddPanel = false },
            addMode = true,
            onClose = { showAddPanel = false },
            vm = connectVm,
        )
    }
    }
}
