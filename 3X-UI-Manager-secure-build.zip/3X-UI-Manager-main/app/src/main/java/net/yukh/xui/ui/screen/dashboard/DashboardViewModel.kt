package net.yukh.xui.ui.screen.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import net.yukh.xui.data.api.dto.PanelUpdateInfo
import net.yukh.xui.data.api.dto.ServerStatus
import net.yukh.xui.data.repo.PanelRepository
import net.yukh.xui.data.repo.ServerTraffic

data class DashboardUiState(
    val status: ServerStatus? = null,
    val onlineEmails: List<String> = emptyList(),
    val clientsTotal: Int? = null,
    val loading: Boolean = false,
    val refreshingNow: Boolean = false,
    val pullRefreshing: Boolean = false,
    val error: String? = null,
    val xrayActionInFlight: Boolean = false,
    val xrayActionMessage: String? = null,
    // Online list dialog — grouped by server (main panel + each node)
    val showOnlineList: Boolean = false,
    val onlineLoading: Boolean = false,
    val onlineGroups: List<OnlineGroup> = emptyList(),
    // Panel update
    val updateInfo: PanelUpdateInfo? = null,
    val updating: Boolean = false,
    val updateMessage: String? = null,
    // Proxied traffic this month for the main panel's own inbounds (nodeId 0).
    val mainTraffic: ServerTraffic? = null,
    // Geo databases: which .dat files are currently re-downloading, + last result.
    val geoUpdating: Set<String> = emptySet(),
    val geoUpdatingAll: Boolean = false,
    val geoMessage: String? = null,
    // Metric-history chart dialog (tap a metric card). null = closed.
    val metricChart: MetricChartState? = null,
) {
    val onlineCount: Int get() = onlineEmails.size
}

/** One server's currently-online clients, for the grouped online dialog. */
data class OnlineGroup(
    val server: String,
    val isMain: Boolean,
    val emails: List<String>,
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repo: PanelRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    private var pollJob: Job? = null

    init {
        // When the user switches to another panel, drop the previous panel's data
        // and reload everything (status + the one-shot cards) for the new one.
        viewModelScope.launch {
            repo.activeProfileId.drop(1).collect {
                _state.update {
                    it.copy(
                        status = null, onlineEmails = emptyList(), clientsTotal = null,
                        updateInfo = null, mainTraffic = null, onlineGroups = emptyList(),
                        error = null, loading = true,
                    )
                }
                refreshUpdateInfo()
                refreshMonthlyTraffic()
                refreshClientsTotal()
                fetchOnce()
            }
        }
    }

    // After a start/stop/restart, the panel keeps reporting the OLD Xray state
    // for a beat (Xray hasn't settled yet). Without this, the immediate refresh
    // would overwrite our optimistic state and the button would flip back for ~3s.
    // So we pin the expected state for a short window; polls update everything
    // else but keep this Xray state until Xray actually settles.
    private var xrayOverrideState: String? = null
    private var xrayOverrideUntil: Long = 0L

    fun startPolling() {
        if (pollJob?.isActive == true) return
        _state.update { it.copy(loading = it.status == null) }
        if (_state.value.updateInfo == null) refreshUpdateInfo()
        if (_state.value.mainTraffic == null) refreshMonthlyTraffic()
        if (_state.value.clientsTotal == null) refreshClientsTotal()
        pollJob = viewModelScope.launch {
            while (isActive) {
                fetchOnce()
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    fun refreshNow() {
        viewModelScope.launch { fetchOnce() }
    }

    /** Manual pull-to-refresh: shows the pull indicator until the fetch returns. */
    fun onPullRefresh() {
        viewModelScope.launch {
            _state.update { it.copy(pullRefreshing = true) }
            fetchOnce()
            refreshUpdateInfo()
            refreshMonthlyTraffic()
            refreshClientsTotal()
            _state.update { it.copy(pullRefreshing = false) }
        }
    }

    private suspend fun fetchOnce() {
        _state.update { it.copy(refreshingNow = true) }
        val statusResult = repo.getServerStatus()
        val onlines = repo.listOnlines().getOrNull()
        statusResult
            .onSuccess { raw ->
                val s = applyXrayOverride(raw)
                _state.update {
                    it.copy(
                        status = s,
                        onlineEmails = onlines ?: it.onlineEmails,
                        loading = false,
                        refreshingNow = false,
                        error = null,
                    )
                }
            }
            .onFailure { e ->
                _state.update { it.copy(loading = false, refreshingNow = false, error = e.message) }
            }
    }

    /** While the post-action window is open, force the Xray state we expect so a
     *  lagging poll doesn't flip the button back. */
    private fun applyXrayOverride(s: ServerStatus): ServerStatus {
        val want = xrayOverrideState ?: return s
        return if (System.currentTimeMillis() < xrayOverrideUntil) {
            s.copy(xray = s.xray.copy(state = want))
        } else {
            xrayOverrideState = null
            s
        }
    }

    // ---- Online list ------------------------------------------------------

    // Shows who is online, grouped by SERVER (main panel first, then each node).
    // The central API can't say which inbound a client uses, but each node is its
    // own 3x-ui panel that reports its own онлайн — so querying every node gives a
    // true per-server breakdown (and reveals a client connected to several nodes
    // at once). Node queries run in parallel.
    fun openOnlineList() {
        _state.update { it.copy(showOnlineList = true, onlineLoading = true, onlineGroups = emptyList()) }
        viewModelScope.launch {
            val online = _state.value.onlineEmails.toSet()
            val nodes = repo.listNodes().getOrNull().orEmpty().filter { it.enable }

            // Panel v3.4.0+: onlinesByGuid returns {panelGuid → [emails]} where
            // each email is attributed to exactly one server — no double-counting.
            val byGuid = repo.onlinesByGuid().getOrNull()

            val groups: List<OnlineGroup>
            if (byGuid != null) {
                // Collect all node guids (non-blank). Any guid key in the response
                // that doesn't match a node belongs to the main panel.
                val nodeGuids = nodes.map { it.guid }.filter { it.isNotBlank() }.toSet()
                val nodeGroups = nodes.map { node ->
                    val emails = if (node.guid.isNotBlank()) {
                        byGuid[node.guid].orEmpty().sorted()
                    } else {
                        // Older node without a guid — query it directly.
                        repo.listNodeOnlines(node).getOrNull().orEmpty().sorted()
                    }
                    OnlineGroup(node.remark.ifBlank { node.name }, isMain = false, emails = emails)
                }
                val mainEmails = byGuid.entries
                    .filter { (guid, _) -> guid !in nodeGuids }
                    .flatMap { (_, emails) -> emails }
                    .sorted()
                groups = listOf(OnlineGroup("", isMain = true, emails = mainEmails)) + nodeGroups
            } else {
                // Fall back to membership-based attribution (panel < 3.4.0).
                val inbounds = repo.listInbounds().getOrNull().orEmpty()
                fun membersOf(nodeId: Int): Set<String> =
                    inbounds.filter { (it.nodeId ?: 0) == nodeId }
                        .flatMap { ib -> ib.clientStats.map { cs -> cs.email } }
                        .toSet()
                val main = OnlineGroup(
                    "", isMain = true,
                    emails = online.filter { it in membersOf(0) }.sorted(),
                )
                val nodeGroups = nodes.map { node ->
                    async {
                        val direct = repo.listNodeOnlines(node)
                        val emails = if (direct.isSuccess) {
                            direct.getOrNull().orEmpty()
                        } else {
                            online.filter { it in membersOf(node.id) }
                        }
                        OnlineGroup(node.remark.ifBlank { node.name }, isMain = false, emails = emails.sorted())
                    }
                }.awaitAll()
                groups = listOf(main) + nodeGroups
            }
            _state.update { it.copy(onlineGroups = groups, onlineLoading = false) }
        }
    }

    fun closeOnlineList() = _state.update { it.copy(showOnlineList = false) }

    // ---- Metric history chart ---------------------------------------------

    /** Open the history chart for a metric block (default interval = 1 hour). */
    fun openMetricChart(block: MetricBlock) {
        _state.update { it.copy(metricChart = MetricChartState(block = block, loading = true)) }
        fetchMetricChart()
    }

    /** Change the chart's interval (API bucket seconds) and reload. */
    fun setMetricBucket(bucket: Int) {
        val mc = _state.value.metricChart ?: return
        _state.update { it.copy(metricChart = mc.copy(bucket = bucket, loading = true)) }
        fetchMetricChart()
    }

    fun closeMetricChart() = _state.update { it.copy(metricChart = null) }

    private fun fetchMetricChart() {
        val mc = _state.value.metricChart ?: return
        viewModelScope.launch {
            val series = mc.block.series.map { def ->
                async {
                    ChartSeries(def.label, repo.metricHistory(def.key, mc.bucket).getOrNull().orEmpty())
                }
            }.awaitAll()
            // Ignore if the user changed the block/bucket meanwhile.
            _state.update { st ->
                val cur = st.metricChart
                if (cur != null && cur.block == mc.block && cur.bucket == mc.bucket) {
                    st.copy(metricChart = cur.copy(series = series, loading = false))
                } else st
            }
        }
    }

    // ---- Panel update -----------------------------------------------------

    private fun refreshUpdateInfo() {
        viewModelScope.launch {
            repo.getPanelUpdateInfo().onSuccess { info -> _state.update { it.copy(updateInfo = info) } }
        }
    }

    // Monthly traffic changes slowly, so (like update info) it's fetched once on
    // start and on pull-to-refresh — not on every 3s status poll, which would pull
    // the whole inbounds list each tick.
    private fun refreshMonthlyTraffic() {
        viewModelScope.launch {
            repo.monthlyTrafficByServer().onSuccess { byServer ->
                _state.update { it.copy(mainTraffic = byServer[0]) }
            }
        }
    }

    // Total client count for the dashboard summary — fetched alongside monthly
    // traffic (once on start + on pull-to-refresh), not every status poll.
    private fun refreshClientsTotal() {
        viewModelScope.launch {
            repo.listClients().onSuccess { list ->
                _state.update { it.copy(clientsTotal = list.size) }
            }
        }
    }

    fun updatePanel() {
        if (_state.value.updating) return
        _state.update { it.copy(updating = true, updateMessage = null) }
        viewModelScope.launch {
            val result = repo.updatePanel()
            _state.update {
                it.copy(
                    updating = false,
                    updateMessage = result.fold(
                        onSuccess = { "Panel update started — it will restart shortly" },
                        onFailure = { e -> "Update failed: ${e.message}" },
                    ),
                )
            }
        }
    }

    fun dismissUpdateMessage() = _state.update { it.copy(updateMessage = null) }

    // ---- Geo databases ----------------------------------------------------

    // Re-download one geo .dat from upstream; the panel restarts Xray afterwards
    // (a brief connection drop), so the screen confirms before calling this.
    fun updateGeofile(fileName: String) {
        if (fileName in _state.value.geoUpdating) return
        _state.update { it.copy(geoUpdating = it.geoUpdating + fileName, geoMessage = null) }
        viewModelScope.launch {
            val result = repo.updateGeofile(fileName)
            _state.update {
                it.copy(
                    geoUpdating = it.geoUpdating - fileName,
                    geoMessage = result.fold(
                        onSuccess = { "$fileName updated — Xray restarted" },
                        onFailure = { e -> "$fileName update failed: ${e.message}" },
                    ),
                )
            }
            // The geo update restarts Xray on the server; pull fresh status so the
            // Xray card reflects the restart instead of waiting for the next tick.
            refreshNow()
        }
    }

    /** Re-download all built-in geo databases in one panel call. */
    fun updateAllGeofiles() {
        if (_state.value.geoUpdatingAll) return
        _state.update { it.copy(geoUpdatingAll = true, geoMessage = null) }
        viewModelScope.launch {
            val result = repo.updateAllGeofiles()
            _state.update {
                it.copy(
                    geoUpdatingAll = false,
                    geoMessage = result.fold(
                        onSuccess = { "Geo databases updated — Xray restarted" },
                        onFailure = { e -> "Geo update failed: ${e.message}" },
                    ),
                )
            }
            refreshNow()
        }
    }

    fun dismissGeoMessage() = _state.update { it.copy(geoMessage = null) }

    // ---- Xray controls ----------------------------------------------------

    // Start/Restart both call restartXrayService (starts Xray when down, restarts
    // when up); Stop uses stopXrayService. NOTE: if the panel is reached *through*
    // Xray (reverse-proxied), stopping Xray cuts off the panel/API and the app
    // can't bring it back. With a direct (non-proxied) connection that's not an
    // issue — so all three are offered and the user picks what's safe for their
    // setup.
    fun startXray() = runXrayAction(verb = "start", resultRunning = true) { repo.restartXray() }
    fun restartXray() = runXrayAction(verb = "restart", resultRunning = true) { repo.restartXray() }
    fun stopXray() = runXrayAction(verb = "stop", resultRunning = false) { repo.stopXray() }

    private fun runXrayAction(
        verb: String,
        resultRunning: Boolean,
        action: suspend () -> Result<Unit>,
    ) {
        if (_state.value.xrayActionInFlight) return
        _state.update { it.copy(xrayActionInFlight = true, xrayActionMessage = null) }
        viewModelScope.launch {
            action()
                .onSuccess {
                    // Reflect the new state immediately AND pin it for a few
                    // seconds so the forced refresh below (and the next poll)
                    // can't flip the button back while Xray is still settling.
                    val newState = if (resultRunning) "running" else "stop"
                    xrayOverrideState = newState
                    xrayOverrideUntil = System.currentTimeMillis() + XRAY_OVERRIDE_MS
                    _state.update { st ->
                        st.copy(
                            xrayActionInFlight = false,
                            xrayActionMessage = "Xray $verb requested",
                            status = st.status?.let { it.copy(xray = it.xray.copy(state = newState)) },
                        )
                    }
                }
                .onFailure { e ->
                    _state.update {
                        it.copy(xrayActionInFlight = false, xrayActionMessage = "Xray $verb failed: ${e.message}")
                    }
                }
            refreshNow()
        }
    }

    fun dismissActionMessage() = _state.update { it.copy(xrayActionMessage = null) }

    override fun onCleared() {
        stopPolling()
        super.onCleared()
    }

    private companion object {
        const val POLL_INTERVAL_MS = 3_000L
        // How long after a start/stop/restart to trust the optimistic Xray state
        // over polled status (enough for Xray to actually settle).
        const val XRAY_OVERRIDE_MS = 6_000L
    }
}
