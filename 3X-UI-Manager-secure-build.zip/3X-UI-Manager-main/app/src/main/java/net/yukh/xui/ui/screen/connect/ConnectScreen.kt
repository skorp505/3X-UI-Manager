package net.yukh.xui.ui.screen.connect

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import net.yukh.xui.data.prefs.ConnectionProfile
import net.yukh.xui.i18n.tr

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectScreen(
    onConnected: () -> Unit,
    addMode: Boolean = false,
    onClose: (() -> Unit)? = null,
    onSettings: (() -> Unit)? = null,
    vm: ConnectViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val editing = state.editingId != null
    var tokenVisible by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(tr(when {
                        editing -> "Edit panel"
                        addMode -> "Add panel"
                        else -> "Connect to panel"
                    }))
                },
                navigationIcon = {
                    if (onClose != null) {
                        IconButton(onClick = onClose) {
                            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = tr("Close"))
                        }
                    }
                },
                actions = {
                    // Settings are otherwise only in the signed-in ⋮ menu; expose
                    // them here so language / version / updates are reachable before
                    // the first sign-in (initial Connect screen only, not add-panel).
                    if (onSettings != null) {
                        IconButton(onClick = onSettings) {
                            Icon(Icons.Outlined.Settings, contentDescription = tr("Settings"))
                        }
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                tr("Sign in with an API token. Requires panel v3.3.0 or newer."),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            OutlinedTextField(
                value = state.url,
                onValueChange = vm::setUrl,
                label = { Text(tr("Panel URL")) },
                placeholder = { Text("https://panel.example.com:2053/") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                supportingText = { Text(tr("Include the webBasePath if your admin set one")) },
            )

            OutlinedTextField(
                value = state.name,
                onValueChange = vm::setName,
                label = { Text(tr("Name (optional)")) },
                placeholder = { Text(ConnectionProfile.hostLabel(ConnectionProfile.normalizeUrl(state.url))) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                supportingText = { Text(tr("Shown in the panel switcher instead of the host.")) },
            )

            OutlinedTextField(
                value = state.token,
                onValueChange = vm::setToken,
                label = { Text(tr("API token")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                visualTransformation = if (tokenVisible) VisualTransformation.None else PasswordVisualTransformation(),
                supportingText = {
                    Text(
                        tr(
                            "Where to get it: open the panel in a browser, go to " +
                                "Settings → Security → API Token, add a token, then copy " +
                                "it here. (3x-ui tokens are full admin — keep it private.)",
                        ),
                    )
                },
                trailingIcon = {
                    IconButton(onClick = { tokenVisible = !tokenVisible }) {
                        Icon(
                            imageVector = if (tokenVisible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                            contentDescription = if (tokenVisible) tr("Hide token") else tr("Show token"),
                        )
                    }
                },
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(tr("Allow self-signed TLS"), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        tr("Disable certificate verification — only enable for your own panel."),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.allowInsecureTls, onCheckedChange = vm::setAllowInsecureTls)
            }

            OutlinedTextField(
                value = state.subBaseUrl,
                onValueChange = vm::setSubBaseUrl,
                label = { Text(tr("Subscription base URL (optional)")) },
                placeholder = { Text("https://panel.example.com:2096/sub/") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                supportingText = {
                    Text(
                        tr(
                            "Optional. The app reads the subscription base from the panel " +
                                "automatically. Set it here only for a reverse proxy whose " +
                                "public URL differs — e.g. https://host:2096/sub/.",
                        ),
                    )
                },
            )

            HorizontalDivider()

            Button(
                onClick = { vm.submit(onConnected) },
                enabled = state.canSubmit,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (state.submitting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                    Text("  " + tr(if (editing) "Saving…" else "Connecting…"))
                } else {
                    Text(tr(if (editing) "Save" else "Connect"))
                }
            }

            state.error?.let {
                Text(
                    text = tr(it),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}
