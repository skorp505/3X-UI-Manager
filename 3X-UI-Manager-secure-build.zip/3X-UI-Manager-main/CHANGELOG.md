# Changelog

All notable changes to the 3X-UI Manager Android app are documented here.
Format based on [Keep a Changelog](https://keepachangelog.com/). Since the
build after 0.15.6 a version is the build date plus a build number that never
resets: `26.10.22.79` = built on 22 October 2026, build 79; the tag is the same
with a `v` (`v26.10.22.79`). Builds 77 and 78 were shown as `26.10.21 build 77`
and tagged `v26.10.21b77`.

🇷🇺 [Версия на русском](CHANGELOG.ru.md)

## [26.10.28.80] — 2026-10-28

### Fixed
- **The client list opens again on panel 3.11.0 when an AmneziaWG client has a keepalive range.** Panel 3.11.0 stores a range such as `15-25` as text, and the app expected a number, so the whole list failed to load. A range now loads, shows in the client editor and is saved back unchanged.

### Added
- **Keepalive ranges for AmneziaWG clients** (panel 3.11.0): the client editor takes `15-25` as well as plain seconds. The app checks the value the way the panel does — 0 to 65535, the lower bound first — and refuses a range when the client is also on a WireGuard inbound, which only takes whole seconds.
- **Node administrator API token scope** (panel 3.11.0): node sync plus starting panel updates. A token with this scope is no longer listed as full access.

## [26.10.22.79] — 2026-10-22

### Fixed
- **F-Droid can build the app again.** Build 78 never reached F-Droid: its version name `26.10.21 build 78` did not match its tag `v26.10.21b78`, so F-Droid could not find the APK. Now the tag is always `v` + the version name — [#12](https://github.com/yukh975/3X-UI-Manager/issues/12), thanks [@linsui](https://github.com/linsui).

### Changed
- **The version reads like its tag**: `26.10.22.79` instead of `26.10.21 build 78`, and the release is tagged `v26.10.22.79`. Earlier builds in the changelog and the update dialog are shown the same way.

## [26.10.21.78] — 2026-10-21

### Changed
- **First public build on the new version format.** The same app as 26.10.21.77; it brings everything from 0.15.5, 0.15.6 and build 77 to GitHub and F-Droid.

## [26.10.21.77] — 2026-10-21

### Changed
- **New version format: build date + build number**, e.g. `26.10.21 build 77`. The number counts every build since the first one and never resets. Installed 0.15.x versions see it as an update as usual.

## [0.15.6] — 2026-10-21

### Fixed
- **The Russian interface no longer mixes in English words.** Inbounds and outbounds are «Входящие» and «Исходящие» everywhere — tab, screen titles, dialogs, field labels and hints — instead of «inbound»/«outbound» or the slang «инбаунд». The 21 strings only the Chinese UI had (`RAM`, `Test mode`, `Real delay`, `unreachable`, …) are now translated too.
- **Russian labels fit on a phone screen:** the «Real delay» chip on the Outbounds screen no longer wraps onto two lines, and the geodata screen title fits on one line.

## [0.15.5] — 2026-10-21

### Added
- **Edit and rename saved panels.** Each panel in the ⇄ switcher has an Edit button: change its name, URL, API token, TLS check or subscription address without removing and re-adding it. A rename alone saves at once; a new URL, token or TLS setting is checked against the panel first. The Connect screen has an optional **Name** field, so a panel can be named when it is added; a panel without a name still shows its host. Thanks to [@m0nty81](https://github.com/m0nty81) — [#11](https://github.com/yukh975/3X-UI-Manager/issues/11).
- **Reset a client's traffic** from its sheet, and **reset traffic of the selected clients** from the multi-select menu. Used traffic starts from zero, and a client its quota switched off is enabled again.
- **MTProto: «Max pending handshakes per IP»** in the inbound editor (panel 3.10.2, needs mtg-multi 1.16.0+): new connections from an IP that already has this many unfinished handshakes are closed; 0 turns it off.

## [0.15.4] — 2026-10-17

### Added
- **Simplified Chinese interface** (Settings → Language). Thanks to [@venti1112](https://github.com/venti1112) — [PR #9](https://github.com/yukh975/3X-UI-Manager/pull/9).
- **Chinese user manual (`docs/3X-UI-MANAGER.zh.md` + PDF) and a Chinese row in every language table.** Thanks to [@venti1112](https://github.com/venti1112) — [PR #10](https://github.com/yukh975/3X-UI-Manager/pull/10).
- **The 20 UI strings that were still missing in Chinese** (`Outbounds`, `RAM`, `Endpoint`, `PSK`, `Target Strategy`, `Real delay`, `unreachable`, …) — the Chinese UI now has no gaps left against the Russian one.

## [0.15.3] — 2026-10-13

### Changed
- **Balancers and the Observatory settings have their own «Balancers» menu item under Routing.** The Routing screen keeps the strategy, rules, route tester and the routing-script warning; rules can still target a balancer. The Observatory section has its own Save button, active only while its settings have unsaved changes.

### Fixed
- **The update dialog now lists the changes of every version since the installed one, not just the latest.** Each version has its own "Version X · date" heading, newest first, so updating over several versions no longer hides what the skipped ones changed.
- **After saving Xray settings the app no longer asks to restart Xray.** Since panel 3.3.1 the panel applies the change itself on save — live through the Xray API where it can (inbounds, outbounds, routing, balancers), restarting Xray only when a change can't be applied live. The inbound save prompt no longer claims Xray will restart. Outbound-subscription refreshes, moves and deletes are applied by the panel within 30 seconds; only editing a subscription still needs a restart, and the app says so.

## [0.15.2] — 2026-10-13

### Added
- **Observatory settings on the Routing screen**, as in panel 3.10.0: for the active observer the probe URL, interval, timeout, sampling and HTTP method, plus the outbounds it watches. The panel and the app manage which observer exists; you tune how it probes.

### Fixed
- **A balancer that needs an observatory made Xray fail to start.** Least Load, and Random / Round-robin with a fallback, need a connection observer; the app never created one, so Xray stopped with "not all dependencies are resolved". The observer is now created, kept in sync with the balancers and removed when nothing needs it, exactly as the panel does it.

## [0.15.1] — 2026-10-13

### Added
- **Panel 3.10.0 support.** The app works with panel 3.10.0 and keeps everything new it adds when you save.
- **MASQUE inbounds** (panel 3.10+): create them with an address pool, MTU and path; TLS is required, so TLS inbounds now have certificate and key file fields. MASQUE clients get their config only through the JSON subscription, so a client's share sheet now also shows the JSON subscription link when the panel serves it.
- **"Use system CA" in outbound TLS** (panel 3.10+): Xray-core 26.10.10 verifies servers against its bundled roots, so an outbound to a server with a private CA needs this switch.
- **Lua scripts and DNS server ID** (panel 3.10+): fields for a DNS server's ID, the DNS Lua script and the routing script. The Routing screen warns when a routing script is set, because Xray then ignores the rules.
- **Hysteria and MASQUE outbounds** (including WARP over MASQUE) now show their transport and TLS settings for editing.
- **Certificate SHA-256 pin field** for nodes that use certificate pinning.

### Fixed
- **A new Shadowsocks inbound could not be created on panel 3.10.** The app now generates a server key of the right length and regenerates it when the method changes; the 2022 ChaCha20 method, which the panel refuses on inbounds, is no longer offered.
- **Save in the outbound editor did not write to the panel**, so leaving the screen lost the change. It now saves at once, like the routing and DNS editors.
- **Saving a DNS server dropped its ID, tag, client IP, expected IPs, skip-fallback and timeout settings.** Expected IPs also showed empty for servers saved by the panel, and Skip fallback showed as on when it was not set.
- **Saving an inbound reset its custom tag, subscription order, "exclude from subscription" flag and monthly reset day.** A custom tag was regenerated, so routing rules pointing at it stopped matching. The Enabled switch in the inbound editor now really turns the inbound on or off.
- **Editing a client turned off its weekly renewal and removed its VLESS reverse proxy.**
- **Editing a node switched "selected inbounds" sync back to "all"**, and nodes using certificate pinning could not be saved at all.
- **A failed attach or detach of a client's inbounds was reported as "Client updated".** The panel's error is shown now. With a MASQUE inbound selected, the client editor refuses an email containing ":".
- **Changing a balancer's strategy dropped its leastLoad settings.**
- **The new-inbound list offered "socks"**, which the panel rejects; it now offers "mixed" (SOCKS + HTTP).
- **WebSocket + TLS inbounds now default to ALPN http/1.1**, so WebSocket connections no longer fail on h2. The inbound editor also hides transport and security choices that would break MASQUE, XDRIVE and TUN inbounds.
- **The QR code is hidden for post-quantum links**, as in the panel: such links are too dense to scan.

## [0.14.3] — 2026-09-15

### Added
- **Update channel in Settings.** The in-app updater now offers a Stable channel (the tested public releases — the default) and an Experimental channel (pre-release builds as soon as they are made, which can be unstable) for trying a build early.

### Fixed
- **Changes in the outbound, routing and DNS editors could not be saved.** These editors (an outbound, a routing rule, a balancer, a DNS server) only had "Done", which staged the change into the list while the screen's Save stayed grey until it was pressed; leaving with the arrow or system Back dropped the change, and Back even closed the whole screen. They now have "Save", which writes the change to the panel at once, and system Back returns to the list. An outbound with an empty or duplicate tag scrolls the form up to the message.

## [0.14.2] — 2026-09-15

### Added
- **A group's card now lists its clients.** Tap a group on the Groups screen to see who is in it, with each client's traffic; tapping a client opens the same sheet as on the Clients screen.

### Fixed
- **An existing node's settings could not be saved.** The Save button wanted the node's API token, which the panel never sends back, so even renaming a node was impossible. Leaving the token field empty now keeps the node's current token, and the app no longer sends an empty token, which panel 3.8.0 would take as a new one.
- **TUIC was missing from the protocol list of a new inbound** on panel 3.8.0. It is there now, with the panel's own default settings; the certificate and key paths still have to be filled in.
- **A set inbound expiry no longer squeezes the date.** The Never and Pick date buttons sat beside the date and wrapped it over several lines; they now sit on their own line under it, as in the client editor.
- **System Back in the outbound editor** closed the whole Outbounds screen and dropped the edits made so far; it now returns to the list, like the editor's own arrow.

## [0.14.1] — 2026-09-15

### Added
- **Support for panel 3.8.0.** What the new panel version brings is offered only when the panel reports 3.8.0 or later; with older panels the app behaves as before.
- **Keepalive for WireGuard and AmneziaWG clients.** The client editor has "Keepalive (seconds)" for clients on tunnel inbounds: a new client gets 25, like the panel's own form, and 0 turns keepalives off. Until now a client created from the app got no keepalive, so an idle peer stayed disconnected after a NAT timeout or a panel restart until its user sent traffic.
- **Encrypted Happ link in the client's share sheet** (panel 3.8.0). When the operator allows encrypted subscription links on the panel, the subscription section creates a `happ://crypt5/…` link with its QR code; otherwise it says where that switch is.
- **Bulk adjust sets the device limit and the MTProto ad tag** (panel 3.8.0) and reports how many clients changed and why any were skipped.
- **The device list shows a short fingerprint** for every registered device (panel 3.8.0), so two similar phones can be told apart.
- **AmneziaWG as an outbound protocol** (panel 3.8.0), with a ready settings skeleton. **Routing rules show their panel-only comment**, and on 3.8.0 it can be edited.
- **TUIC v5 inbounds** (panel 3.8.0) open in the inbound editor without the transport, TLS/REALITY and sniffing sections that don't apply to them, and the client editor explains that per-client traffic and IP limits don't work on TUIC.

### Changed
- **Restoring a database on panel 3.8.0 waits out the panel's own restart.** The panel restarts itself a few seconds after an import; the app now says so and reports when the panel answers again instead of failing requests in the meantime. The restore confirmation also mentions that API tokens come from the backup.

### Fixed
- **A link too long for a QR code could crash the client's share sheet.** The sheet now shows a note in place of the code, and copy and share keep working.
- **With panel 3.8.0, saving a client that isn't on a WireGuard or AmneziaWG inbound wrote a stray `keepAlive: 0` into its settings.** The app now leaves the field out for such clients.

## [0.13.1] — 2026-09-14

### Added
- **Client groups can now be managed from the app.** A client could already be put in a group, but the groups themselves were only reachable in the panel's web UI. The Clients screen's ⋮ menu now opens **Groups**: every group the panel has — empty ones included — with its client count and traffic (↑/↓ and total). From there a group can be created, renamed, given clients or emptied, have its traffic counter reset (each client keeps its own traffic and limits), or be deleted — either the group alone, leaving its clients without a group, or all of its clients, behind a separate confirmation. Resetting a group's traffic requires panel 3.4.2; the upload/download split requires 3.3.1.
- **The client editor offers every group on the panel**, including groups nobody is in yet; before, it only suggested groups some client already used.

## [0.12.3] — 2026-09-14

### Fixed
- **The expiry field in the client editor no longer tears the form apart once an expiry is set.** The "Never" and "Pick date & time" buttons shared one row with the date, squeezed its column to a sliver, and the text stretched into a tall strip with large empty gaps above and below it. The buttons now sit on their own line under the date; a client without an expiry looked right before and still does.

## [0.12.2] — 2026-09-07

### Added
- **A client's expiry now carries a time of day, not just a date.** The panel stores it to the minute and its own form picks both; the app could only pick a day, so half of what the panel showed was unreachable from the phone. Picking an expiry asks for the time after the date and defaults to 23:59 for a client that had none. On the Apple build the expiry could not be edited at all before — it can now.
- **The expiry says which clock it is in.** The value is entered in the phone's time zone — the same way the panel's own web form behaves — and now shows that zone underneath, plus the same instant in the panel's zone when the panel names a real one. A panel abroad and an operator at home no longer have to guess whose midnight was meant.

### Fixed
- An expiry picked in the app was pinned to midnight UTC; it is now built in the phone's own time zone, which is how the panel reads and shows it. West of Greenwich that used to display the day before the one that was picked.

## [0.12.1] — 2026-09-07

### Added
- **Swap usage on the dashboard** (#7) — a tile next to CPU, memory and storage, shown only when the server actually has swap, and tappable for its history like the others.
- **IPv6 address on the dashboard** (#7) — the server's public addresses are now labelled and listed as IPv4 and IPv6 instead of IPv4 alone.
- **Geodata auto-update** — the panel's scheduled geo-database refresh is now editable from the app: the files Xray keeps current, the cron schedule and, optionally, the outbound to download through. Xray reloads them without a restart, so this is the unattended counterpart of the dashboard's manual geo update. Requires panel 3.7.0.
- **The empty IP log now explains itself** — the panel keeps an address for 30 minutes after the last connection, so the log is empty for anyone who has not connected recently; that is no longer indistinguishable from something being broken.

## [0.11.1] — 2026-08-24

### Added
- **Panel 3.7.0 support.** The client editor gained the panel's new fields: **renew on a calendar day** of the month instead of a rolling interval, a **cap on auto-renewals**, the client's **own traffic-reset cycle**, a **device limit** for subscription requests, and **forwarded ports** for AmneziaWG clients.
- **Subscription devices.** A client's registered devices are listed with when each was last seen, and can be removed one at a time or all at once — the way to unlink a phone without touching anything else.
- **Scoped API tokens.** Creating a token now offers its scope — admin, monitor (read-only) or node-sync — and an optional expiry in days. Existing tokens keep full access, as the panel intends.
- **IP limit allowlist** in Panel admin: addresses and networks the panel's IP limit never counts and never bans, so a shared office address can't use up a client's limit.
- **Disable XTLS flow** switch for VLESS inbounds, and a **Reload master credential** button on the Node mTLS screen that applies a rotated certificate without restarting the panel.

### Fixed
- **The update prompt no longer reappears on every launch.** Dismissing it only cleared in-memory state, so the startup check re-opened the same dialog every time until the update was actually installed — on the Apple build, where updating means a manual sideload, that could be a long time. The dismissed version is now remembered; the Dashboard hint and a manual check still show it.
- **Deleting or disabling an API token works on panel 3.7.0.** That panel requires the caller to name the scope it expects, and the app was not sending it, so both actions failed.
- Several UI labels were translated twice with different wording and the later copy silently won — "Fingerprint" and "Outbound test URL" among them.
- **The minimum panel version is v3.3.0, not v3.4.1.** The connect screen overstated it — the app works with v3.3.0, and only some features need a newer panel.

## [0.10.8] — 2026-08-13

### Changed
- **Settings and About are now separate menu items.** About moved out of the Settings screen into its own entry in the ⋮ menu, so neither screen is a grab bag; before you sign in it is still reachable from Settings.
- **About lists our other projects** — the 3x-ui manual, Currency Converter (on F-Droid) and netadm.pro, tools for network and system administrators — each with a one-line description.

## [0.10.7] — 2026-08-13

### Added
- **Panel manual link** in About — opens the project's user manual for the panel.
- **Outbound subscriptions** (#6) — manage the panel's remote outbound lists from the app: add a subscription URL, preview what it yields before saving, set the tag prefix, refresh interval and whether its servers come before your manual outbounds, then enable, refresh, reorder or delete it. Outbounds imported from a subscription are listed on the Outbounds screen and can be tested and targeted by routing rules and balancers, the same as manual ones — they are edited through the subscription rather than directly, which is how the panel works.

### Changed
- **A feature your panel is too old for now says so.** Instead of an error or a missing screen, the section explains that the panel version doesn't support it yet and suggests updating.

### Fixed
- Several UI labels were translated twice with different wording, and the later copy silently won — "Move up/down" and "Enabled" among them. Two others had lost their Russian translation entirely this way.

## [0.10.6] — 2026-08-08

### Fixed
- **F-Droid builds verify again** (#4). The reference binary published for the catalog is now built from a clean checkout of the tag, so it matches F-Droid's own build byte for byte; the previous one was built incrementally and failed verification. F-Droid users get updates again — this release also carries everything from 0.10.2–0.10.5, which were test builds: the subscription-id fix (#3), the Changelog page, and the reworked bottom navigation.

### Added
- **App language now follows the device by default.** A new "System default" option sits above English and Русский, so a Russian phone gets a Russian app straight after install — and switching the device language switches the app, without a restart. An explicit choice still overrides it.

### Changed
- The About button now reads **"Project on GitHub"** instead of asking for a star.

## [0.10.5] — 2026-08-08

### Changed
- **Bottom navigation shows icons only**, with the current tab's name captioned underneath. With an enlarged system font the per-tab labels wrapped onto two lines and pushed the bar out of shape.

### Fixed
- **Changelog page:** the oldest release really is reachable now — the page is drawn as a full screen instead of a dialog, so it gets the system-bar insets it needs (the earlier attempt at this didn't take effect).

## [0.10.4] — 2026-08-08

### Fixed
- **Changelog page:** the last release in the list sat under Android's navigation bar and couldn't be tapped open.

## [0.10.3] — 2026-08-08

### Added
- **Changelog page** in About — browse the full release history in the app, instead of only seeing the notes for the version you happen to be updating to. Works offline; no network access is used to show it.

## [0.10.2] — 2026-08-08

### Fixed
- **Clients created in the app now get a proper subscription ID.** The app left the subscription id empty, so the panel filled it with a raw UUID — the subscription link carried a UUID-shaped id instead of the short id the panel's own web UI generates. The app now mints it in the panel's format (16 lowercase letters/digits). Existing clients are unaffected. Reported in #3.

## [0.10.1] — 2026-08-02

### Added
- **Email (SMTP) sender settings** in Panel admin — set the From address and sender name used in the panel's notification emails, so a relay whose login isn't a bare email address still sends a valid From (fixes strict receivers like Gmail rejecting it). Requires panel v3.6.0.
- **Outbound-down alert threshold** in Panel admin → Notifications — how many consecutive failed probes before an "outbound down" alert fires (1 = alert on the first failure), to quiet false alerts from a flaky outbound. Requires panel v3.6.0.
- **Subscription status in the share sheet** — a client's share sheet now shows the live status the subscriber's own app sees (online + used/total), read from the subscription server. Shown when reachable, hidden otherwise. Requires panel v3.6.0.

## [0.9.5] — 2026-07-13

### Fixed
- **Clients screen showed "Unexpected response" and the dashboard client total showed "--".** A WireGuard client field (`allowedIPs`) was parsed as the wrong type, which broke parsing of the whole client list (the online count kept working — it comes from a separate endpoint). Regression since 0.9.2.

## [0.9.4] — 2026-07-13

### Changed
- **Speed units** are now picked from two explicit options — Bytes (KB/s) / Bits (Kbit/s) — instead of an on/off toggle.
- **About:** "Check for updates" now sits above "Star on GitHub".

## [0.9.3] — 2026-07-13

### Added
- **Speed units** — a toggle in Settings to show live speeds in bits/s (Kbit/s, Mbit/s) instead of bytes/s (KB/s). Applies to inbound and client speeds.

### Fixed
- **Route tester listed raw Xray tags** (e.g. `inbound-127.0.0.2:10000`). It now shows the inbound's remark (falling back to the tag when empty) while still probing by tag.

## [0.9.2] — 2026-07-13

More panel 3.5.0 parity.

### Added
- **Subscription announcement** — a Subscription section in Panel admin to read and edit `subAnnounce`, the banner shown on the subscription info page.
- **MTProto client fields** — when a selected inbound is MTProto, the client editor shows the FakeTLS secret (with a regenerate button) and an ad-tag field (32-hex). Personal `tg://` links already worked through the share sheet.
- **WireGuard allowed IPs** — when a selected inbound is WireGuard, the client editor shows an editable "allowed IPs" field (empty auto-assigns).

### Fixed
- **Route test always said "default outbound".** It never sent the inbound, and most routing rules key on it, so the router couldn't decide. The tester now has an inbound picker and passes it through.
- **Editing MTProto or WireGuard clients could drop their secret / peer keys** — the client model now carries `secret`, `adTag` and the WireGuard peer fields, so a save round-trips them untouched.

## [0.9.1] — 2026-07-13

Feature parity with panel 3.5.0.

### Added
- **Live speed per client** — the Clients screen now shows each client's live ↑/↓ rate (derived from the traffic delta between polls), the same way inbounds already did.
- **Outbound connectivity test** — a Test action per outbound (mode selector: TCP / HTTP / Real delay) that reports the round-trip delay and, for HTTP/Real probes, the egress IP and country (with a WARP marker). The test URL stays server-side.
- **Target Strategy selector** in the outbound editor (AsIs … ForceIPv4), next to Send through.
- **Route test** in the Routing section — enter a domain or IP (plus optional port/network) and see which outbound it resolves to, the balancer chain if any, or a "default outbound" verdict.

### Changed
- **Client search** now matches Telegram ID, comment, sub ID, UUID, password and auth — previously it matched the email only.

## [0.8.10] — 2026-07-10

### Added
- **"Star on GitHub" button in the About screen** — opens the project repository so you can star it. Present in both builds.

### Changed
- **F-Droid build:** the About screen now reads "Installed from F-Droid — updates come through the F-Droid catalog." in place of the (hidden) update-check button, so it's clear where updates come from.
- **F-Droid catalog:** added a launcher-icon PNG to the store metadata so the catalog listing shows the app icon (the pure-vector adaptive icon didn't render there).

## [0.8.9] — 2026-07-07

### Fixed
- **Crash at startup on Android 7 (API 24–25).** Notification channels — an Android 8+ API — were created without a version guard in Application.onCreate, so the app crashed with NoClassDefFoundError before drawing anything. Channel creation is now skipped on pre-Android 8 devices, where per-notification priority carries the importance instead. Found by F-Droid community testing.

## [0.8.8] — 2026-07-07

### Changed
- **Build change for F-Droid.** The APK no longer embeds the Play-oriented dependency-metadata block (an extra APK signing block that F-Droid's scanner rejects). No user-facing changes.

## [0.8.7] — 2026-07-07

### Changed
- **Reproducible builds for F-Droid.** The APK no longer embeds the build's git commit hash (it varied per checkout and broke F-Droid's byte-for-byte verification), so the F-Droid build can be signed with the project's own release key. No user-facing changes.

## [0.8.6] — 2026-07-07

### Changed
- **Build changes for F-Droid.** The version is now declared statically (rather than derived from CI/git) so F-Droid can build the app reproducibly, and the store description moved to fastlane metadata. No user-facing changes.

## [0.8.5] — 2026-07-07

### Added
- **The app is now open source under the MIT license.** A LICENSE file was added and an `fdroid` build flavor prepared so the app can ship on F-Droid (which builds it from source, without the in-app updater). The GitLab-released build is unchanged.

## [0.8.4] — 2026-07-07

### Added
- **Panel alert notifications now include the date and time they fired.** A "panel unreachable" read hours later was ambiguous — by then the panel is often back up, with no way to tell when it actually happened. Each alert now appends the moment it was raised in the device's time zone, e.g. `host · :443 · 07 Jul, 09:59`.

## [0.8.3] — 2026-07-06

### Added
- **Configurable panel port for reachability alerts.** Panel alert settings now have a *Panel port* field (default 443) — the port on the panel host that Panel alerts probe to decide whether the panel is reachable. Handy when your inbounds listen on localhost behind a reverse proxy: monitor the panel's public port instead. Per-inbound ports are still monitored separately, from each inbound's editor.

## [0.8.2] — 2026-07-06

### Fixed
- **Update notes no longer break mid-sentence.** The "What's new" shown in the update dialog was printed with the changelog's source line breaks, so text wrapped in odd places. It now reflows into clean paragraphs that wrap to the dialog width.

## [0.8.1] — 2026-07-06

### Added
- **Per-inbound reachability monitoring.** Each inbound now has a *Monitor
  reachability* switch — turn it on and Panel alerts will TCP-probe that
  inbound's port directly and notify you if it stops answering. Handy for
  inbounds exposed directly, without a reverse proxy. The default port-443 check
  stays; the reachability probe is now a plain TCP port check, so it works for
  any port or protocol.

## [0.7.3] — 2026-07-06

### Changed
- **Panel alerts now check that port 443 is reachable, not the panel API.** The
  management panel is often firewalled off your phone, so its reachability was a
  poor health signal. The "unreachable" alert now checks whether the host answers
  on port 443 (the usual public entry). Client expiry / traffic / Xray / node
  checks still run against the panel API, best-effort (skipped silently when it
  isn't reachable).

## [0.7.2] — 2026-07-02

### Fixed
- **Panel alerts no longer cry wolf.** Turning alerts on could immediately fire a
  false "panel unreachable" for panels that were up: the check ran twice at once
  and the burst of concurrent requests could get rejected. Now the periodic check
  doesn't duplicate the immediate one, an "unreachable" alert needs two failed
  checks in a row, and an invalid token is reported as an auth problem rather than
  an outage.

## [0.7.1] — 2026-07-02

### Added
- **App version on the Dashboard.** A new card right below the panel version
  shows the manager app's own version and highlights when a newer release is
  available — tap it to open the update dialog.

### iOS
- **Subscription sharing + link actions.** The client editor now shows the
  auto-updating subscription link with its QR code (resolved from panel
  settings, like on Android), and every link/QR card gained one-tap *Copy* and
  system *Share* buttons.

## [0.6.1] — 2026-07-02

### Added
- **Panel alerts.** Optional background notifications for the things you'd
  otherwise only catch by opening the app: a client is about to expire or has
  used most of its traffic, or a panel, Xray or node has gone down. Enable it in
  Settings and set the expiry-days / traffic-% thresholds; every saved panel is
  checked. On **Android** a periodic background job polls (~30 min); on **iOS**
  the check runs when you open the app plus opportunistically in the background.

### Fixed
- **Minimum panel version.** The Connect screen now states the real requirement —
  panel **v3.4.1** or newer — instead of the outdated v3.3.0.

## [0.5.7] — 2026-07-02

### Fixed
- **Update notes now match the app language.** The "What's new" shown in the
  in-app update dialog was always in English. It now follows your selected
  language — the notes are pulled from the matching changelog (English or
  Russian) for the offered version.

## [0.5.6] — 2026-07-01

### Fixed
- **Settings on the first screen.** The Connect screen (before you sign in) now
  has a settings button — language, app version, and the update check are
  reachable on a fresh install, not only from the signed-in menu.
- **App-lock passcode resets with the last panel.** Signing out of your last
  panel returns the app to its fresh-install state, so the app-lock passcode is
  cleared too. It's kept as long as any panel is still saved.

## [0.5.5] — 2026-07-01

### Added
- **In-app updates.** The app checks its own GitLab releases on launch (and from
  a *Check for updates* button in Settings / the More tab) and offers the newer
  version with its release notes. On **Android** it downloads the APK and hands it
  to the system installer — an in-place update. On **iOS** an app can't install an
  unsigned build itself, so it opens the release page to re-download and sideload.

## [0.5.4] — 2026-06-29

### Changed
- **One consistent way to leave a panel — "Sign out".** The standalone
  *Disconnect* menu item is gone. Instead, every panel in the ⇄ switcher (even
  when only one is saved) has a *Sign out* action that forgets that panel's
  saved URL and token. Signing out of the last one returns to the Connect
  screen — so it does everything *Disconnect* did, without the inconsistency of
  two different controls.

### iOS
- **Node mTLS is now its own page.** It moved from a card on the Nodes screen to
  a separate "Node mTLS" entry in the More menu — matching the Android app, where
  it has been a standalone page since 0.5.3.
- **The Clients card is first on the dashboard,** matching the Android layout.

## [0.5.3] — 2026-06-29

### Changed
- **Node mTLS is now a full-screen page.** It was the only ⋮-menu entry that
  opened as a dialog; it now matches the other screens (DNS, Outbounds, Routing,
  …) in layout and colours.

## [0.5.2] — 2026-06-29

### Fixed
- **Compact Outbounds toolbar.** The toolbar no longer wraps the "Outbounds"
  title — *Save* is now a diskette icon, and *Import from vless:// link* moved
  into the ⋮ menu (next to Import / Export).

## [0.5.1] — 2026-06-29

### Added
- **Multiple panels — multi-instance.** Connect to several 3x-ui panels and switch
  between them: the ⇄ button in the top bar opens a panel switcher where you can
  switch the active panel, add another (a blank Connect form), or remove one. The
  panel you were already signed into is migrated into the list automatically.
  *Disconnect* now forgets the active panel and falls back to another saved one
  (or the Connect screen when none remain). The active panel is shown in the top
  bar, and switching panels refreshes every data screen.
- **Pull-to-refresh on the Nodes screen.** Swipe down to refresh node statuses,
  the same as on the Dashboard.

### Fixed
- **Node version now refreshes after an update.** A node self-update downloads a
  new build and restarts, which takes far longer than one refresh, so the node's
  version used to stay stale until you left to the Dashboard and came back. The
  app now keeps polling the node until its reported version actually changes.
- **App-lock no longer interrupts a quick switch.** The passcode/biometric lock
  now waits a short grace period before re-locking, so switching to another app
  (e.g. to copy a panel URL) and back doesn't prompt; on unlock it returns you to
  the screen you were on instead of resetting to the Dashboard.

### Changed
- **Update dialogs warn about losing the connection.** Updating a node, updating
  the panel, or restarting the panel now warns that if the app reaches the panel
  *through* it, the connection will drop and you'll need to reconnect manually.

## [0.4.2] — 2026-06-26

### Added
- **Client list: quick enable/disable toggle.** Each client row now has an
  on/off switch (same as inbounds), so you can enable or disable a client
  without opening the detail sheet.

### Fixed
- **Online-by-server list: correct server attribution.** The "Online" dialog
  no longer shows a client as connected to multiple servers simultaneously.
  It now calls `POST /panel/api/clients/onlinesByGuid` (panel v3.4.0+), which
  returns each online email under exactly one server's GUID — so each user
  appears on the server they are actually routed through. For older panels
  (< v3.4.0) the previous membership-based logic is used as a fallback.
- **Client search field height.** The "Search by email" field was stretching
  to two lines when the label text was long; it is now constrained to a single
  line.

### Changed
- **Routing / DNS export and import buttons** are now icon buttons
  (↑ import / ↓ export) instead of small text links, making them easier to
  spot and tap.

---

## [0.4.1] — 2026-06-26

### Added
- **Inbounds: live speed.** The inbounds list now shows each inbound's current
  up/down speed (↑/↓ B/s), polled while the tab is open (panel v3.4.0).
- **Client IP log.** The client sheet gains an *IP log* button that shows the
  client's recent connection IPs with the time and the node (`@ node`) each came
  through, plus a *Clear* action (panel v3.4.0).
- **Inbound: advanced stream-settings (JSON) editor.** A collapsible "Advanced:
  stream settings (JSON)" section makes the whole `streamSettings` object editable,
  so the new 3.4.x TLS/REALITY/transport fields not exposed as structured inputs —
  Verify Peer Cert By Name, Curve Preferences, REALITY Limit Fallback, XHTTP
  Session ID Table/Length, the Real-client-IP sockopt preset, FinalMask, etc. —
  can all be set by hand (matching how outbound advanced settings already work).
- **Node mutual TLS (mTLS).** The node editor adds an "mtls" TLS-verify mode (the
  API token becomes optional), and a **Node mTLS** entry in the ⋮ menu lets you
  copy this panel's CA (to register on a node) and set a trusted parent CA (so a
  managing panel can manage this one as a node). Panel v3.4.0.
- **Node: route the panel→node connection through an outbound.** The node editor
  gains a "Connection outbound" picker (Xray outbound tags, blackhole excluded;
  empty = direct). Panel v3.4.0.
- **Export / import clients + delete unbound.** The Clients ⋮ menu gains Export
  clients (JSON of every `{client, inboundIds}`, copy/share), Import clients
  (paste that JSON — existing emails are skipped), and Delete unbound clients
  (removes clients not attached to any inbound). Panel v3.4.0.
- **VLESS encryption key generator.** In a VLESS inbound, *Generate VLESS
  encryption key* fetches the panel's key options (X25519 / ML-KEM-768 × native /
  xorpub / random), shows the decryption/encryption pair (copyable) and can insert
  the decryption into the inbound's settings (panel v3.4.1, xray-core v26.6.21+).
- **Bulk client actions.** Long-press a client to enter selection mode, then
  enable, disable, adjust (add/subtract days and traffic, set or clear the XTLS
  flow), or delete the selected clients in one go (panel v3.4.1 bulk endpoints).
- **HTTP outbound: custom request headers.** A key/value Headers editor was added
  to the HTTP outbound form for the CONNECT headers sent to the upstream proxy
  (`settings.headers`); previously there was no way to set them.
- **Update nodes to the dev channel.** The node-update confirmation now has a
  "dev build (latest commit)" checkbox — checked, the node installs the rolling
  dev-latest build instead of the stable release (panel v3.4.1).
- **Dashboard client counts.** A card at the top of the dashboard (before CPU)
  shows how many clients there are in total and how many are online right now;
  tap it to open the online-by-server list.
- **Enable / disable routing rules.** Each rule in the Routing editor now has an
  on/off switch (like panel 3.4.x) — a disabled rule is kept but greyed out and
  dropped from the running config by the panel on save (needs panel **v3.4.0+**;
  older panels ignore the flag). The internal stats (`api`) rule stays locked on.
- **Export / import rules, outbounds and DNS servers.** Routing rules, outbounds
  and DNS servers can be exported to JSON (copy or share) and imported back by
  pasting JSON — a bare array, `{rules|outbounds|servers:[…]}`, or the wrapped
  `{routing|dns:…}` form; imported entries are appended.
- **Filter the client list by status and group.** A filter button next to the
  search box (with a badge for the active count) opens a sheet — mirroring the
  panel's filter drawer — that narrows the list by status (**Online**, Active,
  Disabled, Depleted) and by **group** (the groups in use). Sections narrow
  independently; *Clear all* resets them.

### Changed
- **Clearer online dot in the client list.** Online clients are now marked with a
  bright green dot (offline stays gray), so it's obvious at a glance who's
  connected — the old blue dot blended into the card.
- **Inbound editor warns about the reserved API port.** Entering port 62789 (the
  default internal Xray API port) now shows a warning, since the panel rejects a
  loopback inbound on it (v3.4.0).
- **Node deletion is blocked while inbounds are bound.** The Delete button in the
  node editor is disabled (with a hint) until the node's inbounds are detached —
  matching the panel, which rejects the deletion otherwise (v3.4.0).
- **The client list auto-refreshes.** While the Clients tab is open it polls the
  panel every few seconds, so new connections, traffic and online state update
  without a manual pull (panel v3.4.0).
- **WireGuard: the obsolete Workers field is gone.** xray-core v26.6.22 no longer
  uses `workers`, so it was removed from the WireGuard outbound form (existing
  configs are unaffected — the key is simply ignored).
- **Metric-history ranges match the panel (v3.4.x).** The interval selector on
  the dashboard charts is now 2m / 1h / 3h / 6h / 12h / 24h / 2d / 7d (history is
  kept for up to 7 days), replacing the old 30m / 2h / 5h set.
- **Cleaner empty Nodes screen.** "No nodes yet" is now centred with an icon and
  readable margins instead of edge-to-edge left-aligned text.
- **Client group is picked from existing groups.** In the client editor (both
  new and edit) the *Group* field became an autocomplete dropdown listing the
  groups already used by other clients, so you select one instead of retyping it
  by hand — no more typos that silently split a group in two. Typing a brand-new
  name still works, so a new group can be created right there.

## [0.3.23] — 2026-06-11

### Fixed
- **No passcode prompt right after a manual sign-in.** With an app-lock passcode
  set, signing in on the Connect screen (entering the URL + token) popped the
  passcode immediately — pointless, since typing the token is already
  authentication. The lock now arms only when a saved session is auto-restored at
  launch (a returning user) or when the app is backgrounded while connected.
  Follow-up to 0.3.22.

## [0.3.22] — 2026-06-11

### Fixed
- **The app lock (passcode / biometric) is no longer asked while signed out.**
  The passcode guards the panel UI, not the token-entry screen, so a logged-out
  app — sitting on Connect after a disconnect or a dropped token — opens straight
  to the token field with no passcode prompt. It also no longer arms the lock
  when you background the Connect screen. While signed in, backgrounding still
  re-locks and asks for the passcode on return, exactly as before. The passcode
  itself is kept (not reset on logout) — it's just only enforced when there's a
  session to protect.

## [0.3.21] — 2026-06-11

### Changed
- **The app is now token-only and requires panel v3.3.0 or newer.** Login +
  password (and 2FA) sign-in has been removed entirely — the Connect screen asks
  for a panel URL and an **API token** only. On v3.3.0+ a token reaches the whole
  management API, so login no longer buys anything; dropping it removes the
  session/CSRF/cookie machinery and the periodic re-auth (and its 2FA re-prompt).
  An existing token profile keeps working; if you only ever signed in with a
  login, create a token in the panel under **Settings → Security → API Token**.
  The Connect screen now spells out where to find it (a footnote under the token
  field).

## [0.3.20] — 2026-06-11

### Changed
- **An invalid token / expired session now returns you to the Connect screen.**
  If the API token is deleted or disabled in the panel (or a login session
  expires and can't be renewed), the app no longer stays "connected" while every
  request silently fails — it drops back to Connect with a clear message ("Your
  API token is no longer valid…") and the fields pre-filled, so you can re-enter
  a working token and reconnect. Requests now send
  `X-Requested-With: XMLHttpRequest` so the panel reports an auth failure as
  **401** (not 404), which the app can tell apart from a genuine "not found".

## [0.3.19] — 2026-06-11

### Added
- **Panel admin (⋮ menu):** manage the panel itself, all over the token-accessible
  settings API.
  - **Admin account** — change the panel login username + password (the current
    credentials are required to confirm; an API token keeps working afterwards).
  - **API tokens** — list, create (the new token's plaintext value is shown once
    to copy), enable / disable, and delete.
  - **Restart panel** — restart the panel service (confirmed first; the app
    reconnects after a few seconds).

### Changed
- Corrected the stale "an API token can't do this" wording across the app and
  READMEs: on panel **v3.3.0+** a token covers the Xray config editor, settings
  and subscription links. The Xray-config screen's gate is now a neutral "couldn't
  load" message (it only appears on an actual load failure), and the subscription
  hints note that the base is auto-read with a token too.

## [0.3.18] — 2026-06-11

### Added
- **Backup / restore (⋮ menu):** download the panel's database backup to a file,
  and restore the panel from one. The backup is the **whole database** — settings,
  inbounds, clients and the Xray config — so a single file captures everything.
  The panel chooses the engine-specific file (SQLite `x-ui.db` / PostgreSQL
  `x-ui.dump`) and imports either back, so the app stays engine-agnostic. Uses the
  system file picker (Storage Access Framework); restore confirms first and
  restarts Xray (a brief connection drop). Works with an API token
  (`GET /panel/api/server/getDb`, `POST /panel/api/server/importDB`).

### Changed
- Docs: clarified that on panel **v3.3.0+** an API token covers **settings**, the
  **Xray config editor** and **subscription-link auto-discovery** too — the whole
  management surface moved under `/panel/api/*`, which a token authenticates. The
  README previously documented these as login-session-only.

## [0.3.17] — 2026-06-10

### Added
- **Outbounds editor:** a structured Outbounds list under the ⋮ menu (session
  login only, same as the Xray config) — add / edit / delete / reorder outbounds
  (order = priority; index 0 is the default route). Structured forms for vless,
  vmess, trojan, shadowsocks, socks, http, freedom, blackhole and wireguard, with
  transport + security (TCP / WS / gRPC / HTTPUpgrade / xHTTP / kcp, TLS / REALITY)
  for the proxy protocols. **Import from a `vless://` link** — paste a share link
  and it becomes an outbound. Niche types (dns, loopback, WARP, NordVPN, TUN,
  reverse, subscription outbounds) are edited via a raw-JSON box. Every edit
  round-trips through the full config, leaving routing / balancers / DNS /
  observatory intact.
- **Routing editor (⋮ menu):** routing rules (add / edit / delete / reorder —
  inbound / domain / IP / port / source / network / protocol / user → outbound or
  balancer) and balancers (tag / strategy / selector / fallback), plus the routing
  strategy.
- **DNS editor (⋮ menu):** enable toggle, DNS servers (bare address or full
  object — port / query strategy / domains / expected & unexpected IPs / skip-
  fallback / …), FakeDNS pools, and the DNS-level options.
- **General / Logs (⋮ menu):** routing strategy, log levels (access / error /
  mask / DNS log), outbound test URL, and traffic-statistics toggles.
- All four Xray-config sections round-trip through the same config (siblings and
  unknown keys preserved) and are session-login only.

## [0.3.16] — 2026-06-10

### Added
- **App icon:** a custom adaptive launcher icon (indigo “3X” monogram with a
  two-tone X) replaces the system-default icon — the app now shows one consistent
  icon across devices. Includes a monochrome layer for Android 13+ themed icons.
- **Dashboard → Geo databases:** an “Update all” button re-downloads every
  built-in geo database in a single panel call.

### Changed
- **Dashboard → Geo databases:** the card is collapsed by default (header only)
  and expands to the per-file list on tap (accordion).
- **Dashboard:** the online-clients card title no longer says “(tap)”.

## [0.3.15] — 2026-06-10

### Added
- **Dashboard:** tap any system-metric card (CPU, Memory, Disk, Load, Network,
  Connections) to open a **history chart** for that metric, with an interval
  **dropdown** at the top (Real-time / 30 min / 1 hour / 2 / 3 / 5 hours; default
  **Real-time**). Multi-value blocks chart every series — Load as 1m/5m/15m, Network
  as ↑/↓, Connections as TCP/UDP. Data comes from the panel's
  `GET /panel/api/server/history/{metric}/{bucket}` (Bearer-token), ~60 points per
  interval. Percent metrics use a fixed 0–100 % scale; the rest auto-scale.

## [0.3.14] — 2026-06-09

### Added
- **Dashboard:** a "Traffic this month" card showing proxied (VPN) traffic for
  the current month for the **main panel's own inbounds** (sub-nodes excluded),
  with the period start date ("since 01.06"). Computed client-side by grouping
  `/inbounds/list` by `nodeId` and summing up+down — no extra panel calls.
- **Nodes:** each node card now shows its **traffic this month** (that node's own
  inbounds). A trailing `*` flags a group where not every inbound resets monthly
  (its figure then counts all-time, not just this month).
- **Dashboard:** a "Geo databases" card to re-download the panel's built-in geo
  rule files — `geoip.dat`, `geosite.dat`, and the RU/IR variants — one at a time
  (`POST /panel/api/server/updateGeofile/:file`). Each update confirms first,
  since the panel restarts Xray afterwards (a brief connection drop).

### Changed
- **Panel v3.3.0 compatibility:** upstream v3.3.0 moved the Xray-config and
  panel-settings endpoints under `/panel/api/*`. `XuiApi` now targets the new
  paths — and because they accept a Bearer token there, the **Xray config
  editor** and the auto-derived **subscription URL** now work in **API-token**
  mode too (previously login/password only). ⚠️ Requires the panel on **v3.3.0+**.

### Fixed
- **Online by server:** the main-server group no longer lists node-only clients.
  The central onlines endpoint reports online emails across the whole node tree,
  so the main group could show a client that belongs only to a sub-node's inbound
  (e.g. an outbound credential the main server uses to chain to a node). The main
  group is now restricted to clients of the main panel's own inbounds
  (`nodeId` 0); node clients appear under their node. If a node isn't reachable
  directly from the device, its online clients now fall back to inbound-membership
  attribution instead of vanishing from the list.

## [0.3.12] — 2026-06-09

### Changed
- **Dashboard:** every metric is now its own full-width row, in order — CPU,
  Memory, Disk, Load, Net, Connections, Online (previously Load/Net/Connections/
  Online were cramped half-width tiles).
- **Nodes:** redesigned the node card — after the URL, each fact is on its own
  line: CPU · RAM, **Ping** (the ms value is now labelled), inbounds · clients,
  uptime, and the node's 3x-ui version.
- **Clients:** "Expires" now shows the number of **days remaining** (not a date)
  and gets a colon; "Last seen" moved to its own line, also with a colon, and
  reads "Never" for clients that have never connected (was a bare dash).
- **Inbounds:** colon after "Expires".

### Added
- **Nodes:** when a node runs an older 3x-ui than the latest, an **Update**
  button appears that triggers the node's self-update via the central panel
  (`POST /panel/api/nodes/updatePanel`).
- **Release:** the published APK filename now includes the version
  (`3x-ui-manager-<version>.apk`).

## [0.3.11] — 2026-06-08

### Fixed
- After **Start/Stop/Restart Xray** the status card no longer flickers:
  previously the button briefly showed the new state, snapped back to the old
  one, then took ~3 s (next poll) to settle. The panel keeps reporting the old
  Xray state for a moment, and the immediate refresh overwrote the optimistic
  value. Now the expected state is pinned for a few seconds (until Xray actually
  switches) while the dashboard refreshes immediately — no snap-back, no delay.

## [0.3.10] — 2026-06-08

### Changed
- **Restored the Xray Start / Stop buttons** on the dashboard (for all auth
  methods — token and login/password), alongside Restart. The connection loss on
  stop appears to happen only when the panel itself is reverse-proxied through
  Xray; on a direct connection, stopping is safe. The card optimistically shows
  the correct button after an action even if the poll doesn't return.

## [0.3.9] — 2026-06-08

### Added
- **Online clients grouped by server.** Tapping "Online" on the dashboard now
  shows the list grouped by server: the main panel first, then each node with
  its own connected clients. Each node is queried directly via its own API
  (address + token from the nodes list), so you see the real picture — including
  a client connected to several nodes at once (which the central API couldn't
  report). Nodes are queried in parallel.
- **Xray uptime** on the status card (time since the last Xray restart, separate
  from the overall server uptime).

### Changed
- The dashboard now offers only the **Restart Xray** button; Start and Stop are
  removed entirely (for all auth methods). Stopping Xray on panels proxied
  through Xray cuts off the panel itself — confirmed with both token and
  login/password — while Restart is safe.
- The connect screen's auth toggle is shortened to **"API Token" / "Login"** (was
  "Login & password", which overflowed and wrapped, breaking the layout).

## [0.3.8] — 2026-06-08

### Changed
- **Xray controls now depend on the auth method**: with an **API token** only
  **Restart** is available; with **login/password** you get the full
  **Start / Stop / Restart**. Reason: on panels reverse-proxied through Xray,
  stopping Xray cuts off the panel/API and a token session can't bring it back.
  Restart is safe — Xray comes back up and the connection is restored.
- The **online clients list** now shows only emails (no inbound): 3x-ui keys
  online/traffic by email under a single canonical inbound and copies that record
  into every inbound the email belongs to, so the API can't tell which inbounds a
  client is actually live on — showing one would be misleading.

## [0.3.7] — 2026-06-08

### Changed
- The words **inbound/outbound** are no longer translated in the Russian UI
  ("Изменить inbound", "Удалить inbound", …) — they're established terms.
- In the client share sheet, **Edit** and **Delete** are swapped (Edit left,
  Delete right), and **Close** is now a proper button instead of a text link.
- The Xray controls on the dashboard wrap to a centered second line when they
  don't fit one row (e.g. Russian "Перезапустить" + "Остановить").

### Fixed
- After **stopping Xray**, the dashboard immediately shows the "Start" button
  even if the panel connection drops (on setups where the panel is reverse-
  proxied through Xray, the poll after a stop may never return) — previously the
  stale "Restart/Stop" controls stuck around.
- On the **Xray config** screen in API-token mode, the raw "Network error" is no
  longer shown — the explanation that login/password is required is enough.

## [0.3.6] — 2026-06-08

> Every change in this release was verified on an emulator (editor/settings
> screenshots), not just by compiling.

### Fixed
- **Online clients list** now resolves the inbound via `clientStat.inboundId`
  (the one the panel actually tracks the client under) instead of whichever
  inbound's list the client appears in. One email can be a member of several
  inbounds (one user across multiple servers); 3x-ui stores its traffic/online
  under a single canonical inbound and replicates that record into the others,
  which is why all of them used to show. Now only the attributed one does.
- **Delete buttons (inbound/node) no longer run off-screen under the system
  navigation bar.** Editors are now rendered full-screen in the activity window
  (not in a `Dialog`, where Compose never received system-bar insets), and the
  delete button is pinned in a bottom bar that's always visible — no scrolling
  needed to reach it.
- **The Comment field in the client editor is no longer covered by the
  keyboard** — the form lifts above the keyboard so the field stays reachable.
- **Switches/buttons in Settings and the editors no longer overlap Russian
  text** — long labels get their own space (weight) with the control kept to
  the right.

## [0.3.5] — 2026-06-08

### Added
- **Pull-to-refresh on the dashboard** — swipe down from the top to manually
  refresh server status, the online list, and the panel-update check.
- **State-aware Xray controls** on the status card: when running, **Restart**
  and **Stop** (both confirmed); when stopped, only **Start**.

### Fixed
- **Online clients list** now shows only the inbound(s) a client is actually
  connected through right now (by `lastOnline` recency — a client can be on
  several at once), instead of every inbound they're a member of.
- **Delete buttons** in the inbound and node editors are no longer hidden under
  the Android navigation bar, and the **Comment** field in the client editor is
  no longer covered by the keyboard — editor dialogs now honor system insets
  and resize for the keyboard.

### Changed
- **Full Russian UI translation**: dashboard, inbounds, clients, nodes, all
  editors, the Xray config, the share sheet, and the connect screen — previously
  only the menu was translated.

## [0.3.4] — 2026-06-08

### Added
- **Client search by email** — filter the list by typing part of a name/address.
- **Dashboard → Online**: tapping the online count opens a list of currently
  connected clients, each with the inbound(s) they belong to (refreshes every 3 s).
- **Xray version** on the status card and a **3x-ui panel version** card at the
  bottom of the dashboard; when an update is available an "Update" button
  (confirmed) triggers the panel self-update.
- **In-app RU/EN language switch** (Settings, ⋮ menu) — no restart needed.
- **Settings screen** with an "About" section (version, copyright).
- **Session persistence**: auto-relogin on launch and on a 401 response — the
  app no longer kicks you out after a login/password sign-in.
- **App lock**: passcode on launch + fingerprint (biometric) unlock.

### Changed
- The release APK is now named `3x-ui-manager-release.apk` (instead of
  `app-release.apk`), matching the project name.
- CI no longer builds a debug APK — only the signed release is built.
- The releases page and release notes are now in Russian, generated from this
  changelog (the matching version's section).

### Fixed
- The lock screen no longer fails to compile: the biometric prompt labels are
  hoisted into composable scope (`tr()` can't be called from a plain function).

## [0.3.3] — 2026-06-08

### Fixed
- Editor dialogs (client, inbound, node, Xray) now fill the screen height.
  They were sizing to their content, so tall forms overflowed off-screen:
  the content wouldn't scroll and the bottom (Delete button / last field)
  was cut off. The earlier inset tweak didn't address this; the real cause
  was the dialog wrapping content height.

## [0.3.2] — 2026-06-08

### Changed
- Inbound editor is now structured instead of raw JSON: transport (network +
  ws/grpc/httpupgrade fields), security (TLS SNI; Reality dest/serverNames/
  shortIds/fingerprint/keys), and sniffing (switch + checkboxes) are edited
  with dropdowns, switches and fields. Unmodeled config keys are preserved.
  Protocol `settings` (decryption/fallbacks/…) remains under an Advanced
  JSON section.

### Fixed
- The inbound editor no longer shows the inbound's client list. Clients are
  managed on the Clients tab and are kept untouched when an inbound is saved.

## [0.3.1] — 2026-06-08

### Added
- Client email/name is now editable when editing a client (rename).
- Client inbound membership is editable on edit (attach/detach the delta).
- Optional "Subscription base URL" on the connect screen — enables per-client
  subscription links + QR when using an API token (the token can't read the
  panel's subscription settings).
- Confirmation dialog on every save, so nothing is changed by accident.
  Deletes were already confirmed. (The inbound enable/disable toggle stays
  one-tap — it's quick and reversible.)

### Fixed
- Editor dialogs no longer draw under the Android navigation bar — the
  "Delete" button and the last form field are fully visible again.
- The on-screen keyboard no longer covers the focused field in editors.

## [0.3.0] — 2026-06-08

### Added
- **Client editor** — create, edit and delete clients: email, inbound
  membership, traffic limit, IP limit, reset period, expiry (date picker),
  Telegram ID, group, comment.
- **Inbound editor** — create, edit and delete inbounds: remark, port, listen,
  protocol, traffic limit, reset schedule, expiry, and raw-JSON
  `settings` / `streamSettings` / `sniffing` for any transport/TLS/Reality.
- **Nodes tab** — manage remote panels (multi-panel): list with online status,
  CPU/RAM/latency/counts; add, edit, delete.
- **Xray config editor** — edit the full Xray config (outbounds, routing, DNS)
  as JSON. Requires login/password auth (the panel gates it behind a session).
- Subscription URL in the client share sheet, built from the panel's
  subscription settings (login/password auth).

### Changed
- Client share sheet reworked into an accordion: a **Subscription** section
  (QR + link) and a **Connections** section where each link expands to its own
  QR + copy/share.

### Fixed
- Share-sheet action buttons collapsing into an unusable thin strip when a
  client had several connection links.

## [0.2.2] — 2026-06-07

### Fixed
- DTOs now match the real 3x-ui v3.x API responses, fixing the "Unexpected
  response" error on connect: nested `mem`/`xray`/`netIO` objects in server
  status, numeric `tgId` and nested `traffic` on clients, array-shaped client
  links endpoint.
- Login/password flow treats `{success, obj:null}` ack responses as success
  instead of failure.

## [0.2.0] — 2026-06-07

### Added
- Dashboard with live server-status polling.
- Inbounds list with enable/disable toggle and traffic stats.
- Clients list with subscription link and QR code.
- Bottom navigation across Dashboard / Inbounds / Clients.

## [0.1.0] — 2026-06-07

### Added
- First installable build.
- Connect screen with two auth modes: API token, or login/password with
  optional 2FA. Self-signed TLS toggle.
- Project scaffold, GitLab CI, signed-release pipeline with versioning from
  git tags.
