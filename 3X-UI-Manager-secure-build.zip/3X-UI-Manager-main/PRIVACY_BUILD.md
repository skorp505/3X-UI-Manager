# Privacy-focused APK build

This workflow builds the existing `fdroidRelease` product flavor. In this flavor:

- `BuildConfig.IN_APP_UPDATER` is false, so the app's self-update check/download/install flow is disabled.
- `REQUEST_INSTALL_PACKAGES` is removed from the merged manifest.
- The app still uses INTERNET to connect to the 3x-ui server you configure; some Xray connectivity tests may contact their configured probe URL (default Google generate_204).
- This does not change the server API functionality.

## Build

Push this project to a GitHub repository (branch `secure-build`) or run the workflow manually from Actions → Build privacy-focused APK → Run workflow. Download the `3x-ui-manager-fdroid-release` artifact from the completed run.

This is a source-level hardening/build configuration, not a complete independent security audit. Review network calls and the generated APK before using it with a production server.
